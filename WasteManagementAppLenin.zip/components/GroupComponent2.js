import * as React from "react";
import {
  Text,
  StyleSheet,
  View,
  Pressable,
  ImageSourcePropType,
} from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const GroupComponent2 = ({ notification1Traced, onGroupPressablePress }) => {
  return (
    <Pressable
      style={[styles.groupWrapper, styles.groupLayout]}
      onPress={onGroupPressablePress}
    >
      <View style={[styles.groupParent, styles.groupLayout]}>
        <View style={[styles.notificationWrapper, styles.notificationLayout]}>
          <Text style={[styles.notification, styles.notificationLayout]}>
            Notification
          </Text>
        </View>
        <Image
          style={styles.notification1Traced}
          contentFit="cover"
          source={notification1Traced}
        />
        <View style={[styles.ellipseParent, styles.groupChildPosition]}>
          <Image
            style={[styles.groupChild, styles.groupChildPosition]}
            contentFit="cover"
            source={require("../assets/ellipse-37.png")}
          />
          <Text style={styles.text}>2</Text>
        </View>
      </View>
    </Pressable>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 67,
    width: 132,
    top: 0,
    position: "absolute",
  },
  notificationLayout: {
    height: 17,
    left: 0,
    width: 132,
    position: "absolute",
  },
  groupChildPosition: {
    width: 29,
    top: 0,
    position: "absolute",
  },
  notification: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    top: 0,
    height: 17,
  },
  notificationWrapper: {
    top: 50,
  },
  notification1Traced: {
    height: "57.16%",
    width: "24.3%",
    top: "15.67%",
    right: "59.5%",
    bottom: "27.16%",
    left: "16.2%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  groupChild: {
    height: 24,
    left: 0,
  },
  text: {
    top: 2,
    left: 6,
    fontSize: FontSize.size_smi,
    fontWeight: "700",
    fontFamily: FontFamily.nunitoBold,
    color: Color.grayscaleWhite,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 13,
    height: 23,
    position: "absolute",
  },
  ellipseParent: {
    left: 42,
    height: 25,
  },
  groupParent: {
    left: 0,
  },
  groupWrapper: {
    left: 97,
  },
});

export default GroupComponent2;
