import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View } from "react-native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const BottomDrawer = () => {
  return (
    <View style={[styles.bottomDrawer, styles.bottomDrawerPosition]}>
      <View style={[styles.typeSelector, styles.typeSelectorPosition]}>
        <Image
          style={[styles.cinematicIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/cinematic.png")}
        />
        <Text style={[styles.video, styles.videoTypo]}>VIDEO</Text>
        <Text style={[styles.portrait, styles.videoTypo]}>Portrait</Text>
        <Image
          style={[styles.panoIcon, styles.iconPosition]}
          contentFit="cover"
          source={require("../assets/pano.png")}
        />
        <Text style={[styles.photo, styles.videoTypo]}>PHOTO</Text>
      </View>
      <Image
        style={styles.iconShutter}
        contentFit="cover"
        source={require("../assets/icon--shutter.png")}
      />
      <Image
        style={[styles.photoLibraryIcon, styles.typeSelectorPosition]}
        contentFit="cover"
        source={require("../assets/-photo-library.png")}
      />
      <Image
        style={[styles.actionRotate, styles.bottomDrawerPosition]}
        contentFit="cover"
        source={require("../assets/action--rotate.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  bottomDrawerPosition: {
    overflow: "hidden",
    position: "absolute",
  },
  typeSelectorPosition: {
    left: 20,
    position: "absolute",
  },
  iconPosition: {
    height: 10,
    left: "50%",
    top: "50%",
    marginTop: -5,
    position: "absolute",
  },
  videoTypo: {
    textAlign: "left",
    fontFamily: FontFamily.sFCompact,
    textTransform: "uppercase",
    lineHeight: 16,
    letterSpacing: 0,
    fontSize: FontSize.size_sm,
    marginTop: -8,
    left: "50%",
    top: "50%",
    position: "absolute",
  },
  cinematicIcon: {
    marginLeft: -179.5,
    width: 59,
  },
  video: {
    marginLeft: -89.5,
    color: Color.grayscaleWhite,
    textAlign: "left",
    fontFamily: FontFamily.sFCompact,
    textTransform: "uppercase",
    lineHeight: 16,
    letterSpacing: 0,
    fontSize: FontSize.size_sm,
    marginTop: -8,
  },
  portrait: {
    marginLeft: 61.5,
    color: Color.grayscaleWhite,
    textAlign: "left",
    fontFamily: FontFamily.sFCompact,
    textTransform: "uppercase",
    lineHeight: 16,
    letterSpacing: 0,
    fontSize: FontSize.size_sm,
    marginTop: -8,
  },
  panoIcon: {
    marginLeft: 152.5,
    width: 27,
  },
  photo: {
    marginLeft: -18.5,
    fontWeight: "600",
    color: Color.defaultSystemYellowDark,
    textAlign: "left",
    fontFamily: FontFamily.sFCompact,
    textTransform: "uppercase",
    lineHeight: 16,
    letterSpacing: 0,
    fontSize: FontSize.size_sm,
    marginTop: -8,
  },
  typeSelector: {
    right: 28,
    bottom: 171,
    height: 16,
  },
  iconShutter: {
    width: 72,
    height: 72,
  },
  photoLibraryIcon: {
    bottom: 26,
    borderRadius: Border.br_10xs,
    width: 49,
    height: 49,
  },
  actionRotate: {
    right: 20,
    bottom: 27,
    borderRadius: Border.br_81xl,
    width: 48,
    height: 48,
  },
  bottomDrawer: {
    right: -10,
    bottom: 116,
    left: -8,
    backgroundColor: Color.colorGray_500,
    height: 108,
  },
});

export default BottomDrawer;
