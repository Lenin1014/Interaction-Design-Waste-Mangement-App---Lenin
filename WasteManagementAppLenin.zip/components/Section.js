import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import NameInput from "./NameInput";
import RatingScale from "./RatingScale";
import { FontFamily, Color, Border, FontSize, Padding } from "../GlobalStyles";

const Section = () => {
  return (
    <View>
      <View>
        <View style={styles.nameInputParent}>
          <View style={styles.nameInput}>
            <Text style={[styles.name, styles.nameTypo]}>Name</Text>
            <View
              style={[styles.enterUsernameWrapper, styles.textSectionShadowBox]}
            >
              <Text style={[styles.enterUsername, styles.nameTypo]}>
                Widle Studio
              </Text>
            </View>
          </View>
          <NameInput
            contactNumber="Contact Number"
            enterUsername="+91 00000 00000"
          />
        </View>
      </View>
      <NameInput
        contactNumber="Email Address"
        enterUsername="xyz123@gmail.com"
        propMarginTop={30}
      />
      <View style={styles.ratingSection}>
        <Text style={[styles.name, styles.nameTypo]}>
          Share your experience in scaling
        </Text>
        <RatingScale
          worstStyle={require("../assets/worst-style.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style.png")}
          neutral={require("../assets/neutral.png")}
          goodStyle={require("../assets/good-style.png")}
          loveItStyle={require("../assets/love-it-style.png")}
          frame15={require("../assets/frame-15.png")}
        />
      </View>
      <View style={styles.otherCommentsSection}>
        <View style={styles.comments}>
          <View style={[styles.textSection, styles.textSectionShadowBox]} />
          <Image
            style={styles.moreToolIcon}
            contentFit="cover"
            source={require("../assets/more-tool.png")}
          />
          <Text style={styles.addYourComments}>Add your comments...</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  nameTypo: {
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
    textAlign: "left",
  },
  textSectionShadowBox: {
    borderWidth: 1,
    borderStyle: "solid",
    backgroundColor: Color.grayscaleWhite,
    borderRadius: Border.br_4xs,
    shadowOpacity: 1,
    elevation: 2,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowColor: "rgba(0, 0, 0, 0.18)",
  },
  name: {
    fontSize: FontSize.size_sm,
    color: Color.feedform2PrimaryGreenBlue,
    textAlign: "left",
  },
  enterUsername: {
    fontSize: FontSize.size_3xs,
    color: Color.feedform2SecondaryDarkSeaGreen,
    textAlign: "left",
  },
  enterUsernameWrapper: {
    borderColor: Color.feedform2SecondaryDarkSeaGreen,
    width: 160,
    alignItems: "center",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_smi,
    marginTop: 5,
    flexDirection: "row",
  },
  nameInput: {
    height: 60,
    justifyContent: "center",
  },
  nameInputParent: {
    justifyContent: "space-between",
    flexDirection: "row",
    width: 350,
  },
  ratingSection: {
    marginTop: 30,
  },
  textSection: {
    top: 0,
    left: 0,
    borderColor: Color.grayscaleTintedGray,
    position: "absolute",
    height: 85,
    width: 350,
  },
  moreToolIcon: {
    top: 65,
    left: 330,
    width: 15,
    height: 15,
    position: "absolute",
  },
  addYourComments: {
    top: 10,
    left: 10,
    fontSize: FontSize.size_xs,
    fontWeight: "500",
    fontFamily: FontFamily.montserratMedium,
    color: Color.grayscalePaleGray,
    position: "absolute",
    textAlign: "left",
  },
  comments: {
    height: 85,
    width: 350,
  },
  otherCommentsSection: {
    height: 85,
    marginTop: 30,
  },
});

export default Section;
