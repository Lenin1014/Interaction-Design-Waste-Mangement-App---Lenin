import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Color, FontSize, FontFamily, Border } from "../GlobalStyles";

const Datepicker = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.datepicker}>
      <View style={styles.shape} />
      <View style={styles.dates}>
        <Image
          style={styles.selectIcon}
          contentFit="cover"
          source={require("../assets/select.png")}
        />
        <View style={styles.days}>
          <Text style={[styles.s, styles.sTypo]}>S</Text>
          <Text style={[styles.m, styles.sTypo]}>M</Text>
          <Text style={[styles.t, styles.sTypo]}>T</Text>
          <Text style={[styles.w, styles.sTypo]}>W</Text>
          <Text style={[styles.t1, styles.sTypo]}>T</Text>
          <Text style={[styles.f, styles.sTypo]}>F</Text>
          <Text style={[styles.s1, styles.sTypo]}>S</Text>
          <Text style={[styles.text, styles.textTypo4]}>1</Text>
          <Text style={[styles.text1, styles.textTypo3]}>2</Text>
          <Text style={[styles.text2, styles.textPosition]}>3</Text>
          <Text style={[styles.text3, styles.textPosition]}>4</Text>
          <Text style={[styles.text4, styles.textPosition]}>5</Text>
          <Text style={[styles.text5, styles.textPosition]}>6</Text>
          <Text style={[styles.text6, styles.textPosition]}>7</Text>
          <Text style={[styles.text7, styles.textPosition]}>8</Text>
          <Text style={[styles.text8, styles.textPosition]}>9</Text>
          <Text style={[styles.text9, styles.textTypo2]}>10</Text>
          <Text style={[styles.text10, styles.textTypo2]}>11</Text>
          <Text style={[styles.text11, styles.textTypo2]}>12</Text>
          <Text style={[styles.text12, styles.textTypo2]}>13</Text>
          <Text style={[styles.text13, styles.textTypo2]}>14</Text>
          <Text style={[styles.text14, styles.textTypo2]}>15</Text>
          <Text style={[styles.text15, styles.textTypo2]}>16</Text>
          <Text style={[styles.text16, styles.textTypo1]}>17</Text>
          <Text style={[styles.text17, styles.textTypo1]}>18</Text>
          <Text style={[styles.text18, styles.textTypo1]}>19</Text>
          <Text style={[styles.text19, styles.textTypo1]}>20</Text>
          <Text style={[styles.text20, styles.textTypo1]}>21</Text>
          <Text style={[styles.text21, styles.textTypo1]}>22</Text>
          <Text style={[styles.text22, styles.textTypo1]}>23</Text>
          <Text style={[styles.text23, styles.textTypo]}>24</Text>
          <Text style={[styles.text24, styles.textTypo]}>25</Text>
          <Text style={[styles.text25, styles.textTypo]}>26</Text>
          <Text style={[styles.text26, styles.textTypo]}>27</Text>
          <Text style={[styles.text27, styles.textTypo]}>28</Text>
          <Text style={[styles.text28, styles.textTypo]}>29</Text>
          <Text style={[styles.text29, styles.textTypo]}>30</Text>
          <Text style={[styles.text30, styles.textTypo4]}>27</Text>
          <Text style={[styles.text31, styles.textTypo4]}>28</Text>
          <Text style={[styles.text32, styles.textTypo4]}>29</Text>
          <Text style={[styles.text33, styles.textTypo4]}>30</Text>
          <Text style={[styles.text34, styles.textTypo4]}>31</Text>
        </View>
      </View>
      <View style={styles.month}>
        <Text style={styles.february}>February</Text>
        <Image
          style={[styles.shapeIcon, styles.shapeIconLayout]}
          contentFit="cover"
          source={require("../assets/shape.png")}
        />
        <Image
          style={[styles.shapeIcon1, styles.shapeIconLayout]}
          contentFit="cover"
          source={require("../assets/shape1.png")}
        />
      </View>
      <Pressable
        style={[styles.cta, styles.ctaLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro9")}
      >
        <View style={[styles.shape1, styles.ctaLayout]} />
        <Text style={[styles.add, styles.addTypo]}>ADD</Text>
      </Pressable>
      <Text style={[styles.cancel, styles.addTypo]}>Cancel</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  sTypo: {
    textAlign: "left",
    color: Color.purple1,
    fontSize: FontSize.size_mini,
    fontFamily: FontFamily.robotoRegular,
    top: "0%",
    position: "absolute",
  },
  textTypo4: {
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    color: Color.gray6,
  },
  textTypo3: {
    left: "94.95%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  textPosition: {
    top: "35.25%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  textTypo2: {
    top: "53.78%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  textTypo1: {
    top: "72.26%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  textTypo: {
    top: "90.74%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  shapeIconLayout: {
    bottom: "15.24%",
    top: "35.71%",
    width: "1.52%",
    height: "49.05%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  ctaLayout: {
    height: 40,
    width: 100,
    position: "absolute",
  },
  addTypo: {
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.robotoBold,
    fontWeight: "700",
    textAlign: "left",
    position: "absolute",
  },
  shape: {
    top: -115,
    left: 15,
    borderRadius: Border.br_xl,
    backgroundColor: Color.gray1,
    width: 348,
    height: 506,
    position: "absolute",
  },
  selectIcon: {
    height: "13.9%",
    width: "13.14%",
    top: "32.68%",
    right: "28.1%",
    bottom: "53.42%",
    left: "58.76%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    position: "absolute",
  },
  s: {
    left: "0.48%",
  },
  m: {
    left: "15.59%",
  },
  t: {
    left: "31.73%",
  },
  w: {
    left: "46.84%",
  },
  t1: {
    left: "63.01%",
  },
  f: {
    left: "78.78%",
  },
  s1: {
    left: "94.26%",
  },
  text: {
    left: "79.33%",
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  text1: {
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  text2: {
    left: "1.14%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoRegular,
    top: "35.25%",
  },
  text3: {
    left: "16.8%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoRegular,
    top: "35.25%",
  },
  text4: {
    left: "32.42%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoRegular,
    top: "35.25%",
  },
  text5: {
    left: "48.05%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoRegular,
    top: "35.25%",
  },
  text6: {
    left: "63.67%",
    color: Color.gray1,
    fontFamily: FontFamily.robotoRegular,
    top: "35.25%",
  },
  text7: {
    left: "79.29%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  text8: {
    left: "94.95%",
    color: Color.gray6,
    fontFamily: FontFamily.robotoMedium,
    fontWeight: "500",
  },
  text9: {
    left: "0%",
  },
  text10: {
    left: "15.62%",
  },
  text11: {
    left: "31.25%",
  },
  text12: {
    left: "46.91%",
  },
  text13: {
    left: "62.53%",
  },
  text14: {
    left: "78.15%",
  },
  text15: {
    left: "93.78%",
  },
  text16: {
    left: "0%",
  },
  text17: {
    left: "15.62%",
  },
  text18: {
    left: "31.25%",
  },
  text19: {
    left: "46.91%",
  },
  text20: {
    left: "62.53%",
  },
  text21: {
    left: "78.15%",
  },
  text22: {
    left: "93.78%",
  },
  text23: {
    left: "0%",
  },
  text24: {
    left: "15.62%",
  },
  text25: {
    left: "31.25%",
  },
  text26: {
    left: "46.91%",
  },
  text27: {
    left: "62.53%",
  },
  text28: {
    left: "78.15%",
  },
  text29: {
    left: "93.78%",
  },
  text30: {
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
    left: "0%",
  },
  text31: {
    left: "15.62%",
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  text32: {
    left: "31.25%",
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  text33: {
    left: "46.91%",
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  text34: {
    left: "62.53%",
    color: Color.gray6,
    top: "16.78%",
    textAlign: "left",
    fontSize: FontSize.size_mini,
    position: "absolute",
  },
  days: {
    height: "100%",
    width: "100%",
    bottom: "0%",
    left: "0%",
    right: "0%",
    top: "0%",
    position: "absolute",
  },
  dates: {
    height: "48.33%",
    width: "77.15%",
    top: "24%",
    right: "10.85%",
    bottom: "27.66%",
    left: "12%",
    position: "absolute",
  },
  february: {
    left: "35.84%",
    fontSize: FontSize.size_lg,
    fontFamily: FontFamily.robotoBold,
    fontWeight: "700",
    color: Color.gray6,
    textAlign: "left",
    top: "0%",
    position: "absolute",
  },
  shapeIcon: {
    left: "98.48%",
    right: "0%",
  },
  shapeIcon1: {
    right: "98.48%",
    left: "0%",
  },
  month: {
    height: "5.22%",
    width: "73.65%",
    top: "9.7%",
    right: "13.01%",
    bottom: "85.07%",
    left: "13.33%",
    position: "absolute",
  },
  shape1: {
    top: 0,
    borderRadius: Border.br_8xs,
    backgroundColor: Color.grayscaleWhite,
    left: 0,
  },
  add: {
    top: "30%",
    left: "33%",
    color: Color.gray1,
  },
  cta: {
    top: 327,
    left: 234,
  },
  cancel: {
    top: "84.33%",
    left: "17.6%",
    color: Color.gray6,
  },
  datepicker: {
    top: 94,
    shadowColor: "rgba(32, 32, 35, 0.07)",
    shadowOffset: {
      width: 35,
      height: 45,
    },
    shadowRadius: 73,
    elevation: 73,
    shadowOpacity: 1,
    width: 375,
    height: 402,
    left: 0,
    position: "absolute",
  },
});

export default Datepicker;
