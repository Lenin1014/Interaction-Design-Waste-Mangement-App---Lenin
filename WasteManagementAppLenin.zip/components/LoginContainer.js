import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const LoginContainer = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.iphone1415Pro2Inner, styles.groupParentLayout]}>
      <View style={[styles.groupParent, styles.parentGroupPosition]}>
        <Pressable
          style={[styles.rectangleParent, styles.rectangleLayout]}
          onPress={() => navigation.navigate("IPhone1415Pro2")}
        >
          <View style={[styles.groupChild, styles.groupLayout]} />
          <Text style={[styles.login, styles.parentGroupLayout]}>Login</Text>
        </Pressable>
        <View style={[styles.groupContainer, styles.parentGroupPosition]}>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <View style={[styles.groupView, styles.parentGroupLayout]}>
              <View style={[styles.groupParent1, styles.parentGroupLayout]}>
                <View style={[styles.parent, styles.parentGroupLayout]}>
                  <Text style={styles.text}>+91</Text>
                  <Image
                    style={styles.icon}
                    contentFit="cover"
                    source={require("../assets/icon.png")}
                  />
                </View>
                <Text style={[styles.text1, styles.textClr]}>1712345678</Text>
              </View>
              <Image
                style={[styles.groupInner, styles.groupInnerPosition]}
                contentFit="cover"
                source={require("../assets/group-895.png")}
              />
            </View>
          </View>
          <Text style={[styles.enterYourMobile, styles.passwordTypo]}>
            Enter your mobile number
          </Text>
        </View>
        <View
          style={[styles.enterYourPasswordParent, styles.groupContainerLayout]}
        >
          <Text style={[styles.enterYourPassword, styles.passwordTypo]}>
            Enter your password
          </Text>
          <Text style={[styles.forgotPassword, styles.passwordTypo]}>
            forgot password?
          </Text>
          <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
            <View style={[styles.groupItem, styles.groupLayout]} />
            <View style={styles.groupParent2}>
              <View style={[styles.wrapper, styles.text2Layout]}>
                <Text style={[styles.text2, styles.text2Layout]}>
                  **************
                </Text>
              </View>
              <Image
                style={[styles.vectorIcon, styles.groupInnerPosition]}
                contentFit="cover"
                source={require("../assets/vector2.png")}
              />
            </View>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupParentLayout: {
    height: 291,
    width: 332,
    position: "absolute",
  },
  parentGroupPosition: {
    top: 0,
    left: 0,
  },
  rectangleLayout: {
    height: 54,
    left: 0,
    width: 332,
    position: "absolute",
  },
  groupLayout: {
    borderRadius: Border.br_mid_6,
    height: 54,
    left: 0,
    top: 0,
    width: 332,
    position: "absolute",
  },
  parentGroupLayout: {
    height: 16,
    position: "absolute",
  },
  textClr: {
    color: Color.text,
    textAlign: "left",
    lineHeight: 16,
    top: 0,
  },
  groupInnerPosition: {
    top: "0%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    right: "0%",
    position: "absolute",
  },
  passwordTypo: {
    height: 25,
    lineHeight: 26,
    letterSpacing: 0.8,
    textAlign: "left",
    color: Color.colorGray_300,
    fontSize: FontSize.size_base_4,
    fontFamily: FontFamily.hamon,
    position: "absolute",
  },
  groupContainerLayout: {
    width: 332,
    position: "absolute",
  },
  text2Layout: {
    height: 11,
    width: 197,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.mainBlack,
  },
  login: {
    top: 18,
    left: 143,
    fontWeight: "700",
    color: Color.grayscaleWhite,
    textAlign: "center",
    width: 46,
    fontFamily: FontFamily.hamon,
    lineHeight: 16,
    height: 16,
    fontSize: FontSize.size_lg_8,
  },
  rectangleParent: {
    top: 237,
  },
  groupItem: {
    backgroundColor: Color.body,
    borderStyle: "solid",
    borderColor: Color.colorLightgray_100,
    borderWidth: 1.2,
  },
  text: {
    letterSpacing: 0.3,
    width: 21,
    textAlign: "left",
    color: Color.colorGray_300,
    fontSize: FontSize.size_base_4,
    height: 16,
    fontFamily: FontFamily.hamon,
    lineHeight: 16,
    left: 0,
    top: 0,
    position: "absolute",
  },
  icon: {
    height: "41.46%",
    width: "24.45%",
    top: "28.05%",
    bottom: "30.49%",
    left: "75.55%",
    maxHeight: "100%",
    overflow: "hidden",
    maxWidth: "100%",
    right: "0%",
    position: "absolute",
  },
  parent: {
    width: 45,
    left: 0,
    top: 0,
  },
  text1: {
    left: 55,
    letterSpacing: 0.2,
    width: 83,
    fontSize: FontSize.size_base_4,
    color: Color.text,
    height: 16,
    fontFamily: FontFamily.hamon,
    position: "absolute",
  },
  groupParent1: {
    width: 138,
    left: 0,
    top: 0,
  },
  groupInner: {
    height: "96.34%",
    width: "5.47%",
    bottom: "3.66%",
    left: "94.53%",
  },
  groupView: {
    top: 19,
    left: 29,
    width: 283,
  },
  rectangleGroup: {
    top: 34,
  },
  enterYourMobile: {
    width: 192,
    left: 0,
    top: 0,
  },
  groupContainer: {
    height: 88,
    left: 0,
    width: 332,
    position: "absolute",
  },
  enterYourPassword: {
    width: 152,
    left: 0,
    top: 0,
  },
  forgotPassword: {
    top: 97,
    left: 203,
    width: 129,
  },
  text2: {
    letterSpacing: 1.8,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.text,
    textAlign: "left",
    lineHeight: 16,
    top: 0,
    fontSize: FontSize.size_lg_8,
    width: 197,
  },
  wrapper: {
    top: 1,
  },
  vectorIcon: {
    height: "100%",
    width: "6.34%",
    bottom: "0%",
    left: "93.66%",
  },
  groupParent2: {
    top: 20,
    left: 18,
    width: 297,
    height: 12,
    position: "absolute",
  },
  enterYourPasswordParent: {
    top: 106,
    height: 122,
    left: 0,
  },
  groupParent: {
    left: 0,
    height: 291,
    width: 332,
    position: "absolute",
  },
  iphone1415Pro2Inner: {
    top: 380,
    left: 34,
  },
});

export default LoginContainer;
