import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import GroupComponent2 from "./GroupComponent2";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const GroupComponent1 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.rectangleParent}>
      <View style={styles.groupChild} />
      <Image
        style={[styles.house11Traced, styles.tracedLayout]}
        contentFit="cover"
        source={require("../assets/house-1-1-traced.png")}
      />
      <Text style={styles.home}>Home</Text>
      <Pressable
        style={[styles.profileParent, styles.profileLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro10")}
      >
        <Text style={[styles.profile, styles.profileTypo]}>Profile</Text>
        <Image
          style={[styles.group1364Traced, styles.tracedLayout]}
          contentFit="cover"
          source={require("../assets/group-1364-traced.png")}
        />
      </Pressable>
      <View style={[styles.binSelectorWrapper, styles.binLayout]}>
        <Text style={[styles.binSelector, styles.binLayout]}>Bin selector</Text>
      </View>
      <GroupComponent2
        notification1Traced={require("../assets/notification-1-traced.png")}
        onGroupPressablePress={() => navigation.navigate("IPhone1415Pro13")}
      />
      <Pressable
        style={styles.camera}
        onPress={() => navigation.navigate("IPhone1415Pro12")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/camera.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  tracedLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  profileLayout: {
    width: 59,
    position: "absolute",
  },
  profileTypo: {
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    left: 0,
  },
  binLayout: {
    width: 83,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 12,
    elevation: 12,
    shadowOpacity: 1,
    borderRadius: Border.br_xs,
    backgroundColor: Color.grayscaleWhite,
    left: 0,
    top: 0,
    height: 75,
    width: 384,
    position: "absolute",
  },
  house11Traced: {
    height: "50.67%",
    width: "10.39%",
    top: "16%",
    right: "82.14%",
    bottom: "33.33%",
    left: "7.47%",
  },
  home: {
    left: 29,
    color: Color.colorForestgreen_100,
    width: 63,
    height: 17,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    top: 50,
    position: "absolute",
  },
  profile: {
    top: 38,
    height: 21,
    width: 59,
    position: "absolute",
  },
  group1364Traced: {
    height: "54.58%",
    width: "74.24%",
    top: "0%",
    right: "24.92%",
    bottom: "45.42%",
    left: "0.84%",
  },
  profileParent: {
    top: 11,
    left: 317,
    height: 59,
  },
  binSelector: {
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    left: 0,
    width: 83,
    top: 0,
  },
  binSelectorWrapper: {
    left: 199,
    height: 21,
    top: 50,
    width: 83,
  },
  icon: {
    width: "100%",
    height: "100%",
    overflow: "hidden",
  },
  camera: {
    left: 219,
    top: 6,
    width: 43,
    height: 38,
    position: "absolute",
  },
  rectangleParent: {
    top: 736,
    left: 5,
    height: 75,
    width: 384,
    position: "absolute",
  },
});

export default GroupComponent1;
