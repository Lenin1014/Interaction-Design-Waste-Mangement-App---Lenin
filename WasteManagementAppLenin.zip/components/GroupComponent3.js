import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import { Padding, Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const GroupComponent3 = () => {
  return (
    <View style={styles.rectangleParent}>
      <View style={styles.groupChild} />
      <Image
        style={styles.groupItem}
        contentFit="cover"
        source={require("../assets/rectangle-181.png")}
      />
      <Text style={styles.wereSoftTargets}>
        ‘We’re soft targets’: In Sandeshkhali, journalists attacked by mob,
        restricted ...
      </Text>
      <View style={[styles.politicsWrapper, styles.wrapperBorder]}>
        <Text style={styles.politics}>politics</Text>
      </View>
      <View style={[styles.violenceWrapper, styles.wrapperBorder]}>
        <Text style={styles.politics}>violence</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperBorder: {
    paddingVertical: Padding.p_9xs,
    paddingHorizontal: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    overflow: "hidden",
    height: 23,
    borderColor: Color.colorRoyalblue_100,
    backgroundColor: Color.colorRoyalblue_200,
    borderRadius: Border.br_xl,
    top: 89,
    borderWidth: 1,
    borderStyle: "solid",
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorDarkslategray_300,
    borderColor: Color.colorDimgray_100,
    borderWidth: 1,
    borderStyle: "solid",
    borderRadius: Border.br_xs,
    top: 0,
    height: 122,
    width: 353,
    left: 0,
    position: "absolute",
  },
  groupItem: {
    width: 165,
    borderRadius: Border.br_xs,
    top: 0,
    height: 122,
    left: 0,
    position: "absolute",
  },
  wereSoftTargets: {
    top: 15,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.interRegular,
    textAlign: "left",
    width: 164,
    color: Color.grayscaleWhite,
    left: 177,
    position: "absolute",
  },
  politics: {
    fontSize: FontSize.size_xs,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    textAlign: "center",
    color: Color.grayscaleWhite,
  },
  politicsWrapper: {
    width: 59,
    left: 177,
  },
  violenceWrapper: {
    left: 243,
    width: 65,
  },
  rectangleParent: {
    top: 132,
    height: 122,
    width: 353,
    left: 0,
    position: "absolute",
  },
});

export default GroupComponent3;
