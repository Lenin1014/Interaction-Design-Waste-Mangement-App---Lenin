import React, { useMemo } from "react";
import { StyleSheet, View, Text, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { Border, Color, FontSize, FontFamily, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent4 = ({
  rectangle18,
  part230FirmsWhoDonatedRs3,
  finance,
  propTop,
  propLeft,
  propWidth,
}) => {
  const groupView1Style = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  const frameViewStyle = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth),
    };
  }, [propWidth]);

  return (
    <View style={[styles.rectangleParent, groupView1Style]}>
      <View style={[styles.groupChild, styles.groupChildBorder]} />
      <Image
        style={[styles.groupItem, styles.groupPosition]}
        contentFit="cover"
        source={rectangle18}
      />
      <Text style={[styles.part230, styles.part230Position]}>
        {part230FirmsWhoDonatedRs3}
      </Text>
      <View
        style={[styles.financeWrapper, styles.part230Position, frameViewStyle]}
      >
        <Text style={styles.finance}>{finance}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildBorder: {
    borderWidth: 1,
    borderStyle: "solid",
  },
  groupPosition: {
    borderRadius: Border.br_xs,
    height: 122,
    left: 0,
    top: 0,
    position: "absolute",
  },
  part230Position: {
    left: 177,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorDarkslategray_300,
    borderColor: Color.colorDimgray_100,
    borderRadius: Border.br_xs,
    height: 122,
    left: 0,
    top: 0,
    position: "absolute",
    width: 353,
    borderWidth: 1,
    borderStyle: "solid",
  },
  groupItem: {
    width: 165,
  },
  part230: {
    top: 15,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.interRegular,
    textAlign: "left",
    width: 164,
    color: Color.grayscaleWhite,
  },
  finance: {
    fontSize: FontSize.size_xs,
    fontWeight: "800",
    fontFamily: FontFamily.interExtraBold,
    textAlign: "center",
    color: Color.grayscaleWhite,
  },
  financeWrapper: {
    top: 89,
    borderRadius: Border.br_xl,
    backgroundColor: Color.colorRoyalblue_200,
    borderColor: Color.colorRoyalblue_100,
    width: 59,
    height: 23,
    overflow: "hidden",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_9xs,
    borderWidth: 1,
    borderStyle: "solid",
  },
  rectangleParent: {
    height: 122,
    left: 0,
    top: 0,
    position: "absolute",
    width: 353,
  },
});

export default GroupComponent4;
