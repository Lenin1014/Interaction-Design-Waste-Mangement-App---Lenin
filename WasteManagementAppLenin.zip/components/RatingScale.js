import React, { useMemo } from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, ImageSourcePropType } from "react-native";
import { Padding, Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const RatingScale = ({
  worstStyle,
  itsJustFineStyle,
  neutral,
  goodStyle,
  loveItStyle,
  frame15,
  propMarginTop,
  propPosition,
  propTop,
  propLeft,
  propColor,
  propColor1,
  propColor2,
  propColor3,
  propColor4,
  propWidth,
  propWidth1,
  propWidth2,
  propWidth3,
  propAlignSelf,
}) => {
  const ratingScaleStyle = useMemo(() => {
    return {
      ...getStyleValue("marginTop", propMarginTop),
      ...getStyleValue("position", propPosition),
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propMarginTop, propPosition, propTop, propLeft]);

  const worstStyle1 = useMemo(() => {
    return {
      ...getStyleValue("color", propColor),
    };
  }, [propColor]);

  const notGoodStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor1),
    };
  }, [propColor1]);

  const fineStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor2),
    };
  }, [propColor2]);

  const lookGoodStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor3),
    };
  }, [propColor3]);

  const veryGoodStyle = useMemo(() => {
    return {
      ...getStyleValue("color", propColor4),
    };
  }, [propColor4]);

  const sliderStyle = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth),
    };
  }, [propWidth]);

  const sliderRulerStyle = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth1),
    };
  }, [propWidth1]);

  const frameView1Style = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth2),
    };
  }, [propWidth2]);

  const rectangleViewStyle = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth3),
      ...getStyleValue("alignSelf", propAlignSelf),
    };
  }, [propWidth3, propAlignSelf]);

  return (
    <View style={[styles.ratingScale, ratingScaleStyle]}>
      <View style={styles.emojis}>
        <View style={styles.worst}>
          <Image
            style={styles.worstStyleIcon}
            contentFit="cover"
            source={worstStyle}
          />
          <Text style={[styles.worst1, worstStyle]}>Worst</Text>
        </View>
        <View style={[styles.notGood, styles.goodSpaceBlock]}>
          <Image
            style={styles.worstStyleIcon}
            contentFit="cover"
            source={itsJustFineStyle}
          />
          <Text style={[styles.notGood1, styles.goodTypo, notGoodStyle]}>{`Not 
Good`}</Text>
        </View>
        <View style={[styles.notGood, styles.goodSpaceBlock]}>
          <Image
            style={styles.worstStyleIcon}
            contentFit="cover"
            source={neutral}
          />
          <Text style={[styles.notGood1, styles.goodTypo, fineStyle]}>
            Fine
          </Text>
        </View>
        <View style={[styles.notGood, styles.goodSpaceBlock]}>
          <Image
            style={styles.worstStyleIcon}
            contentFit="cover"
            source={goodStyle}
          />
          <Text style={[styles.notGood1, styles.goodTypo, lookGoodStyle]}>{`Look
Good`}</Text>
        </View>
        <View style={[styles.veryGood, styles.goodSpaceBlock]}>
          <Image
            style={styles.worstStyleIcon}
            contentFit="cover"
            source={loveItStyle}
          />
          <Text
            style={[styles.veryGood1, styles.goodTypo, veryGoodStyle]}
          >{`Very
Good`}</Text>
        </View>
      </View>
      <View style={[styles.slider, sliderStyle]}>
        <View style={[styles.sliderBg, styles.sliderBgLayout]} />
        <View
          style={[styles.sliderRuler, styles.sliderPosition, sliderRulerStyle]}
        >
          <View style={[styles.sliderRulerInner, frameView1Style]}>
            <View
              style={[
                styles.frameChild,
                styles.sliderBgLayout,
                rectangleViewStyle,
              ]}
            />
          </View>
          <Image
            style={styles.sliderRulerChild}
            contentFit="cover"
            source={frame15}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  goodSpaceBlock: {
    marginLeft: 15,
    padding: Padding.p_3xs,
    justifyContent: "center",
  },
  goodTypo: {
    color: Color.feedform2SecondaryCrystal,
    marginTop: 2,
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
  },
  sliderBgLayout: {
    height: 8,
    borderRadius: Border.br_3xl,
  },
  sliderPosition: {
    left: 0,
    position: "absolute",
  },
  worstStyleIcon: {
    width: 40,
    height: 40,
  },
  worst1: {
    color: Color.feedform2SecondaryDarkSeaGreen,
    marginTop: 2,
    fontFamily: FontFamily.montserratBold,
    fontWeight: "700",
    fontSize: FontSize.size_xs,
    textAlign: "left",
  },
  worst: {
    padding: Padding.p_3xs,
    justifyContent: "center",
    alignItems: "center",
  },
  notGood1: {
    textAlign: "center",
  },
  notGood: {
    alignItems: "center",
  },
  veryGood1: {
    textAlign: "left",
    color: Color.feedform2SecondaryCrystal,
  },
  veryGood: {
    alignItems: "flex-end",
  },
  emojis: {
    flexDirection: "row",
  },
  sliderBg: {
    top: 10,
    backgroundColor: Color.feedform2SecondaryCrystal,
    left: 0,
    position: "absolute",
    width: 350,
  },
  frameChild: {
    backgroundColor: Color.feedform2SecondaryDarkSeaGreen,
    width: 49,
  },
  sliderRulerInner: {
    paddingTop: Padding.p_3xs,
    paddingRight: Padding.p_3xs,
    paddingBottom: Padding.p_3xs,
  },
  sliderRulerChild: {
    width: 24,
    height: 24,
    marginLeft: -24,
  },
  sliderRuler: {
    top: 0,
    width: 57,
    alignItems: "center",
    flexDirection: "row",
  },
  slider: {
    height: 28,
    width: 350,
  },
  ratingScale: {
    height: 120,
    marginTop: 10,
  },
});

export default RatingScale;
