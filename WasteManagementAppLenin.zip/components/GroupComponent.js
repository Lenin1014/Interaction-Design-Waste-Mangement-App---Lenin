import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { FontSize, FontFamily, Color, Border } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const GroupComponent = ({
  enterYourPassword,
  vector,
  propTop,
  propLeft,
  propWidth,
  propRight,
  propLeft1,
}) => {
  const groupViewStyle = useMemo(() => {
    return {
      ...getStyleValue("top", propTop),
      ...getStyleValue("left", propLeft),
    };
  }, [propTop, propLeft]);

  const enterYourPasswordStyle = useMemo(() => {
    return {
      ...getStyleValue("width", propWidth),
    };
  }, [propWidth]);

  const vectorIconStyle = useMemo(() => {
    return {
      ...getStyleValue("right", propRight),
      ...getStyleValue("left", propLeft1),
    };
  }, [propRight, propLeft1]);

  return (
    <View style={[styles.enterYourPasswordParent, groupViewStyle]}>
      <Text
        style={[
          styles.enterYourPassword,
          styles.textFlexBox,
          enterYourPasswordStyle,
        ]}
      >
        {enterYourPassword}
      </Text>
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <View style={styles.groupParent}>
          <View style={[styles.wrapper, styles.textPosition]}>
            <Text style={[styles.text, styles.textPosition]}>
              **************
            </Text>
          </View>
          <Image
            style={[styles.vectorIcon, vectorIconStyle]}
            contentFit="cover"
            source={vector}
          />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textFlexBox: {
    textAlign: "left",
    top: 0,
  },
  groupChildLayout: {
    height: 50,
    left: 0,
    width: 325,
    position: "absolute",
  },
  textPosition: {
    width: 193,
    left: 0,
    position: "absolute",
  },
  enterYourPassword: {
    fontSize: FontSize.size_base_4,
    letterSpacing: 0.8,
    lineHeight: 26,
    fontFamily: FontFamily.hamon,
    color: Color.colorGray_300,
    width: 149,
    height: 23,
    left: 0,
    textAlign: "left",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_mid_6,
    backgroundColor: Color.body,
    borderStyle: "solid",
    borderColor: Color.colorLightgray_100,
    borderWidth: 1.2,
    top: 0,
    height: 50,
  },
  text: {
    fontSize: FontSize.size_lg_8,
    letterSpacing: 1.8,
    lineHeight: 16,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    color: Color.text,
    height: 11,
    textAlign: "left",
    top: 0,
  },
  wrapper: {
    top: 1,
    height: 10,
  },
  vectorIcon: {
    height: "100%",
    width: "6.34%",
    top: "0%",
    right: "0.03%",
    bottom: "0%",
    left: "93.63%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  groupParent: {
    top: 19,
    left: 17,
    width: 290,
    height: 12,
    position: "absolute",
  },
  rectangleParent: {
    top: 32,
  },
  enterYourPasswordParent: {
    top: 343,
    left: 32,
    height: 82,
    width: 325,
    position: "absolute",
  },
});

export default GroupComponent;
