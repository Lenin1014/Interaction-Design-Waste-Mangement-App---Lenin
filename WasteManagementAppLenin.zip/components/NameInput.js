import React, { useMemo } from "react";
import { Text, StyleSheet, View } from "react-native";
import { FontSize, FontFamily, Color, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const NameInput = ({ contactNumber, enterUsername, propMarginTop }) => {
  const nameInputStyle = useMemo(() => {
    return {
      ...getStyleValue("marginTop", propMarginTop),
    };
  }, [propMarginTop]);

  return (
    <View style={[styles.nameInput, nameInputStyle]}>
      <Text style={styles.contactNumber}>{contactNumber}</Text>
      <View style={styles.enterUsernameWrapper}>
        <Text style={styles.enterUsername}>{enterUsername}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  contactNumber: {
    fontSize: FontSize.size_sm,
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.feedform2PrimaryGreenBlue,
    textAlign: "left",
  },
  enterUsername: {
    fontSize: FontSize.size_3xs,
    fontStyle: "italic",
    fontFamily: FontFamily.montserratItalic,
    color: Color.grayscaleTintedGray,
    textAlign: "left",
  },
  enterUsernameWrapper: {
    shadowColor: "rgba(0, 0, 0, 0.18)",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowRadius: 2,
    elevation: 2,
    shadowOpacity: 1,
    borderRadius: Border.br_4xs,
    backgroundColor: Color.grayscaleWhite,
    borderStyle: "solid",
    borderColor: Color.grayscaleTintedGray,
    borderWidth: 1,
    width: 160,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: Padding.p_3xs,
    paddingVertical: Padding.p_smi,
    marginTop: 5,
  },
  nameInput: {
    height: 60,
    justifyContent: "center",
  },
});

export default NameInput;
