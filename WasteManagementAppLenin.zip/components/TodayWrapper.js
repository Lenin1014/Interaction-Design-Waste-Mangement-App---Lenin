import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const TodayWrapper = () => {
  return (
    <View style={styles.todayParent}>
      <Text style={styles.today}>Today</Text>
      <Text style={styles.today}>Today</Text>
      <Text style={[styles.bristolCouncil, styles.bristolCouncilTypo]}>
        Bristol Council
      </Text>
      <Text style={[styles.binCollectionDate, styles.bristolCouncilTypo]}>
        Bin collection date
      </Text>
      <Text style={[styles.updateAplication, styles.bristolCouncilTypo]}>
        Update Aplication
      </Text>
      <Text style={[styles.minAgo, styles.minTypo]}>24min ago</Text>
      <Text style={[styles.minAgo1, styles.minTypo]}>24min ago</Text>
      <Image
        style={[styles.groupChild, styles.groupChildLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-38.png")}
      />
      <Image
        style={[styles.groupItem, styles.groupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-40.png")}
      />
      <Image
        style={[styles.groupInner, styles.groupLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-41.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.groupChildLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-39.png")}
      />
      <Image
        style={[styles.groupChild1, styles.groupChildLayout]}
        contentFit="cover"
        source={require("../assets/ellipse-42.png")}
      />
      <Text style={[styles.fineForUn, styles.fineForUnTypo]}>
        Fine for un seperate
      </Text>
      <Text style={[styles.yourNextCollectio, styles.fineForUnTypo]}>
        your next collectio...
      </Text>
      <Text style={[styles.minAgo2, styles.minTypo]}>2min ago</Text>
      <Image
        style={[styles.groupChild, styles.groupChildLayout]}
        contentFit="cover"
        source={require("../assets/mask-group1.png")}
      />
      <Image
        style={[styles.ellipseIcon, styles.groupChildLayout]}
        contentFit="cover"
        source={require("../assets/mask-group2.png")}
      />
      <Image
        style={styles.categories1Traced}
        contentFit="cover"
        source={require("../assets/categories-1-traced.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  bristolCouncilTypo: {
    height: 26,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_mini,
    left: 104,
    textAlign: "left",
    color: Color.colorDimgray_200,
    position: "absolute",
  },
  minTypo: {
    height: 23,
    color: Color.colorSilver,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    position: "absolute",
  },
  groupChildLayout: {
    height: 62,
    left: 22,
    width: 62,
    position: "absolute",
  },
  groupLayout: {
    height: 11,
    width: 12,
    left: 0,
    position: "absolute",
  },
  fineForUnTypo: {
    left: 103,
    height: 23,
    color: Color.colorSilver,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.poppinsRegular,
    textAlign: "left",
    position: "absolute",
  },
  today: {
    top: 0,
    fontSize: FontSize.size_mid,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    height: 30,
    width: 62,
    textAlign: "left",
    color: Color.colorDimgray_200,
    left: 0,
    position: "absolute",
  },
  bristolCouncil: {
    top: 52,
    width: 127,
  },
  binCollectionDate: {
    width: 161,
    top: 140,
  },
  updateAplication: {
    top: 228,
    width: 156,
  },
  minAgo: {
    width: 81,
    height: 23,
    color: Color.colorSilver,
    fontSize: FontSize.size_smi,
    left: 267,
    top: 165,
  },
  minAgo1: {
    top: 253,
    width: 81,
    height: 23,
    color: Color.colorSilver,
    fontSize: FontSize.size_smi,
    left: 104,
  },
  groupChild: {
    top: 48,
  },
  groupItem: {
    top: 72,
  },
  groupInner: {
    top: 160,
  },
  ellipseIcon: {
    top: 136,
  },
  groupChild1: {
    top: 224,
  },
  fineForUn: {
    width: 149,
    top: 77,
  },
  yourNextCollectio: {
    width: 147,
    top: 165,
    left: 103,
  },
  minAgo2: {
    width: 72,
    top: 77,
    height: 23,
    color: Color.colorSilver,
    fontSize: FontSize.size_smi,
    left: 267,
  },
  categories1Traced: {
    height: "9.62%",
    width: "7.96%",
    top: "84.41%",
    right: "80.75%",
    bottom: "5.98%",
    left: "11.29%",
    maxWidth: "100%",
    overflow: "hidden",
    maxHeight: "100%",
    position: "absolute",
  },
  todayParent: {
    left: 19,
    width: 348,
    height: 286,
    top: 140,
    position: "absolute",
  },
});

export default TodayWrapper;
