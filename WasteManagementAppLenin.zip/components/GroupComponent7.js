import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import GroupComponent2 from "./GroupComponent2";
import { FontFamily, FontSize, Border, Color } from "../GlobalStyles";

const GroupComponent7 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.rectangleParent}>
      <View style={styles.groupChild} />
      <Pressable
        style={styles.house11Traced}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/house-1-1-traced2.png")}
        />
      </Pressable>
      <Text style={[styles.home, styles.homeTypo]}>Home</Text>
      <Pressable
        style={[styles.profileParent, styles.profileLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro10")}
      >
        <Text style={[styles.profile, styles.profileLayout]}>Profile</Text>
        <Image
          style={[styles.group1364Traced, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/group-1364-traced.png")}
        />
      </Pressable>
      <View style={[styles.binSelectorWrapper, styles.binLayout]}>
        <Text style={[styles.binSelector, styles.binLayout]}>Bin selector</Text>
      </View>
      <GroupComponent2
        notification1Traced={require("../assets/notification-1-traced1.png")}
        onGroupPressablePress={() => navigation.navigate("IPhone1415Pro13")}
      />
      <Image
        style={styles.cameraIcon}
        contentFit="cover"
        source={require("../assets/camera2.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  homeTypo: {
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
  },
  profileLayout: {
    width: 59,
    position: "absolute",
  },
  binLayout: {
    width: 83,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 12,
    elevation: 12,
    shadowOpacity: 1,
    borderRadius: Border.br_xs,
    backgroundColor: Color.grayscaleWhite,
    left: 0,
    top: 0,
    height: 75,
    width: 384,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  house11Traced: {
    left: "7.47%",
    top: "16%",
    right: "82.14%",
    bottom: "33.33%",
    width: "10.39%",
    height: "50.67%",
    position: "absolute",
  },
  home: {
    top: 50,
    left: 29,
    width: 63,
    height: 17,
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  profile: {
    top: 38,
    height: 21,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    color: Color.labelColorLightPrimary,
    left: 0,
  },
  group1364Traced: {
    height: "54.58%",
    width: "74.24%",
    top: "0%",
    right: "24.92%",
    bottom: "45.42%",
    left: "0.84%",
    position: "absolute",
  },
  profileParent: {
    top: 11,
    left: 317,
    height: 59,
  },
  binSelector: {
    color: Color.colorForestgreen_100,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    width: 83,
    left: 0,
    top: 0,
  },
  binSelectorWrapper: {
    top: 49,
    left: 202,
    height: 21,
  },
  cameraIcon: {
    top: 6,
    left: 219,
    width: 43,
    height: 38,
    overflow: "hidden",
    position: "absolute",
  },
  rectangleParent: {
    top: 736,
    left: 5,
    height: 75,
    width: 384,
    position: "absolute",
  },
});

export default GroupComponent7;
