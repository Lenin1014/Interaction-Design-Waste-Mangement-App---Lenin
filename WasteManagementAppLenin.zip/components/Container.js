import * as React from "react";
import { Text, StyleSheet, View } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const Container = () => {
  return (
    <View style={styles.orParent}>
      <Text style={styles.or}>or</Text>
      <View style={styles.groupParent}>
        <View style={[styles.rectangleParent, styles.groupLayout]}>
          <View style={[styles.groupChild, styles.groupLayout]} />
          <View style={[styles.continueWithGoogleParent, styles.googleLayout]}>
            <Text style={[styles.continueWithGoogle, styles.continueTypo]}>
              Continue with Google
            </Text>
            <Image
              style={[styles.googleIcon, styles.iconPosition]}
              contentFit="cover"
              source={require("../assets/google1.png")}
            />
          </View>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <View style={[styles.groupChild, styles.groupLayout]} />
          <View style={[styles.continueWithAppleParent, styles.appleLayout]}>
            <Text style={[styles.continueWithApple, styles.continueTypo]}>
              Continue with Apple
            </Text>
            <Image
              style={[styles.appleLogoIcon, styles.appleLayout]}
              contentFit="cover"
              source={require("../assets/apple-logo.png")}
            />
          </View>
        </View>
      </View>
      <Text style={styles.dontHaveAnContainer}>
        <Text style={styles.dontHaveAn}>{`Don’t have an account? `}</Text>
        <Text style={styles.signIn}>Sign in</Text>
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  groupLayout: {
    height: 50,
    left: 0,
    width: 325,
    position: "absolute",
  },
  googleLayout: {
    height: 25,
    position: "absolute",
  },
  continueTypo: {
    height: 15,
    color: Color.colorGray_300,
    lineHeight: 16,
    textAlign: "left",
    fontFamily: FontFamily.hamon,
    fontSize: FontSize.size_base_4,
    position: "absolute",
  },
  iconPosition: {
    overflow: "hidden",
    top: 0,
    left: 0,
  },
  appleLayout: {
    height: 21,
    position: "absolute",
  },
  or: {
    marginLeft: -7.35,
    top: 31,
    width: 15,
    height: 14,
    textAlign: "left",
    color: Color.text,
    fontFamily: FontFamily.hamon,
    fontWeight: "700",
    fontSize: FontSize.size_base_4,
    left: "50%",
    position: "absolute",
  },
  groupChild: {
    borderRadius: Border.br_mid_6,
    backgroundColor: Color.body,
    borderStyle: "solid",
    borderColor: Color.colorLightgray_100,
    borderWidth: 1.2,
    top: 0,
  },
  continueWithGoogle: {
    top: 5,
    left: 37,
    width: 141,
  },
  googleIcon: {
    width: 26,
    height: 25,
    position: "absolute",
  },
  continueWithGoogleParent: {
    top: 13,
    left: 63,
    width: 178,
  },
  rectangleParent: {
    top: 0,
  },
  continueWithApple: {
    top: 3,
    left: 35,
    width: 133,
  },
  appleLogoIcon: {
    width: 22,
    overflow: "hidden",
    top: 0,
    left: 0,
  },
  continueWithAppleParent: {
    top: 15,
    left: 65,
    width: 168,
  },
  rectangleGroup: {
    top: 67,
  },
  groupParent: {
    top: 57,
    height: 117,
    left: 0,
    width: 325,
    position: "absolute",
  },
  dontHaveAn: {
    color: Color.text,
    fontFamily: FontFamily.hamon,
  },
  signIn: {
    color: Color.mainBlack,
    fontFamily: FontFamily.hamon,
    fontWeight: "700",
  },
  dontHaveAnContainer: {
    marginLeft: -107.15,
    letterSpacing: 0.2,
    lineHeight: 26,
    textAlign: "center",
    width: 214,
    height: 23,
    top: 0,
    fontSize: FontSize.size_base_4,
    left: "50%",
    position: "absolute",
  },
  orParent: {
    marginLeft: -164.6,
    top: 627,
    height: 174,
    width: 325,
    left: "50%",
    position: "absolute",
  },
});

export default Container;
