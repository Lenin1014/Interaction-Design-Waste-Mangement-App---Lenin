import React, { useMemo } from "react";
import { Text, StyleSheet, View, ImageSourcePropType } from "react-native";
import { Image } from "expo-image";
import { Color, FontFamily, FontSize, Border, Padding } from "../GlobalStyles";

const getStyleValue = (key, value) => {
  if (value === undefined) return;
  return { [key]: value === "unset" ? undefined : value };
};
const StatusBariPhone15Pro = ({ dynamicIsland, data, batteryMarginLeft }) => {
  const statusBariPhone15ProStyle = useMemo(() => {
    return {
      ...getStyleValue("marginLeft", batteryMarginLeft),
    };
  }, [batteryMarginLeft]);

  return (
    <View
      style={[
        styles.statusBariphone15pro,
        styles.parentPosition,
        statusBariPhone15ProStyle,
      ]}
    >
      <View style={[styles.statusBariphone15proInner, styles.statusFlexBox]}>
        <View style={[styles.parent, styles.parentFlexBox]}>
          <Text style={[styles.text, styles.textTypo]} numberOfLines={1}>
            9:41
          </Text>
          <Image
            style={styles.arrowIcon}
            contentFit="cover"
            source={require("../assets/arrow.png")}
          />
        </View>
      </View>
      <View style={styles.dynamicIslandWrapper}>
        <Image
          style={styles.dynamicIslandIcon}
          contentFit="cover"
          source={dynamicIsland}
        />
      </View>
      <View style={[styles.statusBariphone15proChild, styles.parentFlexBox]}>
        <View style={styles.dataParent}>
          <Image style={styles.dataIcon} contentFit="cover" source={data} />
          <View style={styles.battery}>
            <Image
              style={[styles.vectorIcon, styles.vectorIconPosition]}
              contentFit="cover"
              source={require("../assets/vector.png")}
            />
            <Image
              style={[styles.vectorIcon1, styles.vectorIconPosition]}
              contentFit="cover"
              source={require("../assets/vector1.png")}
            />
            <Text style={[styles.text1, styles.textTypo]}>32</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  parentPosition: {
    left: "50%",
    flexDirection: "row",
    position: "absolute",
  },
  statusFlexBox: {
    flex: 1,
    overflow: "hidden",
  },
  parentFlexBox: {
    justifyContent: "center",
    alignItems: "center",
  },
  textTypo: {
    textAlign: "center",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.sFPro,
    letterSpacing: 0,
  },
  vectorIconPosition: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "0%",
    bottom: "0%",
    top: "0%",
    height: "100%",
    overflow: "hidden",
    position: "absolute",
  },
  text: {
    fontSize: FontSize.size_mid,
    lineHeight: 17,
    fontWeight: "600",
    overflow: "hidden",
  },
  arrowIcon: {
    width: 14,
    height: 14,
  },
  parent: {
    marginTop: -9,
    marginLeft: -25.25,
    top: "50%",
    height: 18,
    flexDirection: "row",
    left: "50%",
    position: "absolute",
  },
  statusBariphone15proInner: {
    height: 60,
    overflow: "hidden",
  },
  dynamicIslandIcon: {
    borderRadius: Border.br_13xl,
    width: 192,
    height: 36,
    overflow: "hidden",
  },
  dynamicIslandWrapper: {
    paddingHorizontal: 0,
    paddingVertical: Padding.p_xs,
    overflow: "hidden",
  },
  dataIcon: {
    width: 18,
    height: 14,
  },
  vectorIcon: {
    width: "100%",
    right: "0%",
    opacity: 0.3,
  },
  vectorIcon1: {
    width: "36.67%",
    right: "63.33%",
  },
  text1: {
    left: 6,
    fontSize: FontSize.size_2xs,
    lineHeight: 14,
    fontWeight: "700",
    top: 0,
    position: "absolute",
    textAlign: "center",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.sFPro,
    letterSpacing: 0,
  },
  battery: {
    width: 27,
    marginLeft: 10,
    height: 14,
  },
  dataParent: {
    flexDirection: "row",
  },
  statusBariphone15proChild: {
    paddingHorizontal: Padding.p_9xl,
    paddingVertical: Padding.p_4xl,
    overflow: "hidden",
    flex: 1,
  },
  statusBariphone15pro: {
    marginLeft: -196.5,
    width: 393,
    flexDirection: "row",
    top: 0,
  },
});

export default StatusBariPhone15Pro;
