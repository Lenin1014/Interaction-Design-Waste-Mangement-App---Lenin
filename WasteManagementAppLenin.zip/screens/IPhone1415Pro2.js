import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import Container from "../components/Container";
import { useNavigation } from "@react-navigation/native";
import GroupComponent from "../components/GroupComponent";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const IPhone1415Pro2 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro3}>
      <Image
        style={styles.iphone1415Pro3Child}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island2.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <Container />
      <Pressable
        style={[styles.rectangleParent, styles.rectangleLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <View style={[styles.groupChild, styles.groupLayout1]} />
        <Text style={[styles.signUp, styles.groupLayout]}>sign up</Text>
      </Pressable>
      <View style={[styles.groupParent, styles.parentLayout]}>
        <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
          <View style={[styles.groupItem, styles.groupLayout1]} />
          <View style={[styles.groupContainer, styles.groupLayout]}>
            <View style={[styles.groupView, styles.groupLayout]}>
              <View style={[styles.parent, styles.groupLayout]}>
                <Text style={styles.text}>+91</Text>
                <Image
                  style={[styles.icon, styles.iconLayout]}
                  contentFit="cover"
                  source={require("../assets/icon1.png")}
                />
              </View>
              <Text style={styles.text1}>1712345678</Text>
            </View>
            <Image
              style={[styles.groupInner, styles.iconLayout]}
              contentFit="cover"
              source={require("../assets/group-8951.png")}
            />
          </View>
        </View>
        <Text style={[styles.enterYourMobile, styles.enterTypo]}>
          Enter your mobile number
        </Text>
      </View>
      <View style={[styles.enterYourEmailParent, styles.parentLayout]}>
        <Text style={[styles.enterYourEmailContainer, styles.enterTypo]}>
          {`Enter your `}
          <Text style={styles.email}>Email</Text>
        </Text>
        <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
          <View style={[styles.groupItem, styles.groupLayout1]} />
          <View style={[styles.groupWrapper, styles.wrapperLayout]}>
            <View style={[styles.abc12gmailcomWrapper, styles.wrapperLayout]}>
              <Text style={styles.abc12gmailcom}>abc12@gmail.com</Text>
            </View>
          </View>
        </View>
      </View>
      <GroupComponent
        enterYourPassword="Enter your password"
        vector={require("../assets/vector3.png")}
      />
      <GroupComponent
        enterYourPassword="Re-Enter your password"
        vector={require("../assets/vector4.png")}
        propTop={446}
        propLeft={31}
        propWidth={175}
        propRight="0%"
        propLeft1="93.66%"
      />
      <Text style={styles.register}>Register</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  rectangleLayout: {
    height: 50,
    width: 325,
    position: "absolute",
  },
  groupLayout1: {
    borderRadius: Border.br_mid_6,
    top: 0,
    height: 50,
    width: 325,
    left: 0,
    position: "absolute",
  },
  groupLayout: {
    height: 15,
    position: "absolute",
  },
  parentLayout: {
    height: 82,
    width: 325,
    left: 32,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    right: "0%",
    position: "absolute",
    overflow: "hidden",
  },
  enterTypo: {
    height: 23,
    lineHeight: 26,
    letterSpacing: 0.8,
    textAlign: "left",
    color: Color.colorGray_300,
    fontSize: FontSize.size_base_4,
    fontFamily: FontFamily.hamon,
    top: 0,
    left: 0,
    position: "absolute",
  },
  wrapperLayout: {
    height: 10,
    width: 193,
    position: "absolute",
  },
  iphone1415Pro3Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    left: "50%",
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.mainBlack,
  },
  signUp: {
    marginTop: -7.25,
    marginLeft: -32.35,
    top: "50%",
    fontSize: FontSize.size_lg_8,
    textTransform: "capitalize",
    color: Color.grayscaleWhite,
    width: 65,
    textAlign: "center",
    fontFamily: FontFamily.hamon,
    fontWeight: "700",
    lineHeight: 16,
    height: 15,
    left: "50%",
  },
  rectangleParent: {
    top: 555,
    left: 32,
    width: 325,
  },
  groupItem: {
    backgroundColor: Color.body,
    borderStyle: "solid",
    borderColor: Color.colorLightgray_100,
    borderWidth: 1.2,
  },
  text: {
    letterSpacing: 0.3,
    width: 20,
    textAlign: "left",
    fontSize: FontSize.size_base_4,
    color: Color.colorGray_300,
    height: 15,
    fontFamily: FontFamily.hamon,
    lineHeight: 16,
    top: 0,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "41.45%",
    width: "24.32%",
    top: "27.63%",
    bottom: "30.92%",
    left: "75.68%",
  },
  parent: {
    width: 44,
    top: 0,
    left: 0,
  },
  text1: {
    left: 54,
    letterSpacing: 0.2,
    width: 81,
    color: Color.text,
    textAlign: "left",
    fontSize: FontSize.size_base_4,
    height: 15,
    fontFamily: FontFamily.hamon,
    lineHeight: 16,
    top: 0,
    position: "absolute",
  },
  groupView: {
    width: 135,
    top: 0,
    left: 0,
  },
  groupInner: {
    height: "96.71%",
    width: "5.48%",
    top: "0%",
    bottom: "3.29%",
    left: "94.52%",
  },
  groupContainer: {
    top: 18,
    left: 28,
    width: 277,
  },
  rectangleGroup: {
    top: 32,
    left: 0,
  },
  enterYourMobile: {
    width: 188,
  },
  groupParent: {
    top: 148,
  },
  email: {
    textTransform: "lowercase",
  },
  enterYourEmailContainer: {
    width: 117,
  },
  abc12gmailcom: {
    letterSpacing: 1.6,
    fontWeight: "500",
    fontFamily: FontFamily.interMedium,
    height: 11,
    width: 193,
    color: Color.text,
    textAlign: "left",
    fontSize: FontSize.size_base_4,
    lineHeight: 16,
    top: 0,
    left: 0,
    position: "absolute",
  },
  abc12gmailcomWrapper: {
    top: 0,
    left: 0,
  },
  groupWrapper: {
    top: 20,
    left: 17,
  },
  enterYourEmailParent: {
    top: 242,
  },
  register: {
    marginLeft: -57.5,
    top: 78,
    fontSize: 30,
    letterSpacing: 0.9,
    lineHeight: 28,
    width: 111,
    height: 25,
    color: Color.colorGray_300,
    textAlign: "center",
    fontFamily: FontFamily.hamon,
    fontWeight: "700",
    left: "50%",
    position: "absolute",
  },
  iphone1415Pro3: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default IPhone1415Pro2;
