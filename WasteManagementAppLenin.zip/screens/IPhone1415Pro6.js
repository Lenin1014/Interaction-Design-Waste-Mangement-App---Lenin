import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import Section from "../components/Section";
import { FontSize, Border, Color, FontFamily, Padding } from "../GlobalStyles";

const IPhone1415Pro6 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro12}>
      <Image
        style={styles.iphone1415Pro12Child}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island6.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <Text style={[styles.feedbackForm, styles.wrapperLayout]}>
        Feedback Form
      </Text>
      <Pressable
        style={[styles.wrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View style={styles.feedback}>
        <View style={styles.backWrapper}>
          <Text style={[styles.back, styles.backTypo]}>Back</Text>
        </View>
        <View style={styles.sectionParent}>
          <Section />
          <Pressable
            style={[styles.button, styles.buttonFlexBox]}
            onPress={() => navigation.navigate("IPhone1415Pro7")}
          >
            <View style={[styles.submitButton, styles.buttonFlexBox]}>
              <Text style={[styles.submit, styles.backTypo]}>SUBMIT</Text>
            </View>
          </Pressable>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperLayout: {
    height: 23,
    position: "absolute",
  },
  backTypo: {
    fontSize: FontSize.size_sm,
    textAlign: "left",
  },
  buttonFlexBox: {
    width: 350,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
  },
  iphone1415Pro12Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    left: 0,
    width: 390,
    height: 34,
    position: "absolute",
  },
  feedbackForm: {
    top: 74,
    left: 86,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.labelColorLightPrimary,
    width: 267,
    textAlign: "left",
    height: 23,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 22,
    top: 85,
    width: 14,
  },
  back: {
    fontFamily: FontFamily.montserratRegular,
    color: Color.feedform2PrimaryGreenBlue,
  },
  backWrapper: {
    width: 360,
    paddingHorizontal: 0,
    paddingVertical: Padding.p_3xs,
    flexDirection: "row",
    alignItems: "center",
  },
  submit: {
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: Color.grayscaleWhite,
  },
  submitButton: {
    shadowColor: "rgba(0, 0, 0, 0.4)",
    shadowRadius: 2,
    elevation: 2,
    borderRadius: Border.br_5xs,
    backgroundColor: Color.feedform2PrimarySeaGreen,
    height: 45,
    paddingHorizontal: 11,
    paddingVertical: 7,
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    width: 350,
  },
  button: {
    marginTop: 40,
  },
  sectionParent: {
    marginTop: 20,
    alignItems: "center",
  },
  feedback: {
    top: 171,
    left: 8,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowRadius: 4,
    elevation: 4,
    borderRadius: Border.br_xs,
    backgroundColor: Color.grayscaleWhite,
    width: 385,
    height: 604,
    paddingHorizontal: 25,
    paddingTop: Padding.p_3xs,
    paddingBottom: 30,
    justifyContent: "center",
    alignItems: "center",
    shadowOpacity: 1,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    position: "absolute",
  },
  iphone1415Pro12: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro6;
