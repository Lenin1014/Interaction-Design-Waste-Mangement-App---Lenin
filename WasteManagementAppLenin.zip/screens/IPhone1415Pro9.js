import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Pressable, Text } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, FontSize, Color, Border } from "../GlobalStyles";

const IPhone1415Pro9 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro10}>
      <Image
        style={styles.iphone1415Pro10Child}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island9.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("IPhone1415Pro4")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View style={styles.rectangleParent}>
        <View style={styles.groupChild} />
        <Image
          style={styles.groupItem}
          contentFit="cover"
          source={require("../assets/line-1.png")}
        />
        <Text style={[styles.text, styles.textTypo1]}>72</Text>
        <Text style={[styles.kg, styles.kgTypo]}>kg</Text>
        <Text style={[styles.janFebMar, styles.kgTypo]}>
          Jan Feb Mar Apr May June
        </Text>
        <Image
          style={styles.groupInner}
          contentFit="cover"
          source={require("../assets/ellipse-11.png")}
        />
      </View>
      <View style={[styles.iphone1415Pro10Inner, styles.groupViewLayout]}>
        <View style={[styles.rectangleGroup, styles.groupViewLayout]}>
          <View style={[styles.rectangleView, styles.groupChildShadowBox]} />
          <View style={[styles.targetParent, styles.parentPosition]}>
            <Text style={[styles.target, styles.nowTypo]}>Target</Text>
            <Text style={[styles.text1, styles.textTypo]}>65</Text>
          </View>
        </View>
      </View>
      <View style={[styles.groupView, styles.groupViewLayout]}>
        <View style={[styles.rectangleGroup, styles.groupViewLayout]}>
          <View style={[styles.groupChild1, styles.groupChildShadowBox]} />
          <View style={[styles.changeParent, styles.parentPosition]}>
            <Text style={[styles.target, styles.nowTypo]}>Change</Text>
            <Text style={[styles.text2, styles.textTypo]}>-3.1</Text>
          </View>
        </View>
      </View>
      <View style={[styles.iphone1415Pro10Item, styles.groupChildShadowBox]} />
      <View style={[styles.rectangleParent1, styles.groupChild2Layout]}>
        <View style={[styles.groupChild2, styles.groupChild2Layout]} />
        <Image
          style={styles.plusIcon}
          contentFit="cover"
          source={require("../assets/plus.png")}
        />
      </View>
      <Text style={styles.status}>status</Text>
      <Text style={[styles.good, styles.textTypo1]}>GOOD</Text>
      <View style={[styles.iphone1415Pro10Inner1, styles.groupViewLayout]}>
        <View style={[styles.rectangleGroup, styles.groupViewLayout]}>
          <View style={[styles.groupChild3, styles.groupChildShadowBox]} />
          <View style={styles.nowParent}>
            <Text style={[styles.now, styles.nowTypo]}>Now</Text>
            <Text style={[styles.text2, styles.textTypo]}>{`72.2
`}</Text>
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  textTypo1: {
    textAlign: "left",
    fontFamily: FontFamily.rubikRegular,
    position: "absolute",
  },
  kgTypo: {
    fontFamily: FontFamily.rubikBold,
    fontWeight: "700",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.grayscaleWhite,
    position: "absolute",
  },
  groupViewLayout: {
    height: 84,
    width: 99,
  },
  groupChildShadowBox: {
    borderRadius: Border.br_xl,
    elevation: 4,
    shadowRadius: 4,
    backgroundColor: Color.gray1,
    shadowOpacity: 1,
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    position: "absolute",
  },
  parentPosition: {
    height: 51,
    left: 24,
    top: 14,
    position: "absolute",
  },
  nowTypo: {
    top: 34,
    fontFamily: FontFamily.rubikBold,
    fontWeight: "700",
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.grayscaleWhite,
    position: "absolute",
  },
  textTypo: {
    fontSize: FontSize.size_5xl,
    textAlign: "left",
    color: Color.grayscaleWhite,
    fontFamily: FontFamily.rubikRegular,
    top: 0,
    position: "absolute",
  },
  groupChild2Layout: {
    height: 67,
    width: 67,
    position: "absolute",
  },
  iphone1415Pro10Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    borderRadius: Border.br_81xl,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    top: 64,
    width: 14,
    height: 23,
    left: 26,
    position: "absolute",
  },
  groupChild: {
    shadowRadius: 7,
    elevation: 7,
    borderRadius: 25,
    backgroundColor: Color.gray1,
    shadowOpacity: 1,
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 0,
    height: 350,
    width: 350,
    left: 0,
    position: "absolute",
  },
  groupItem: {
    top: 136,
    left: 25,
    width: 301,
    height: 60,
    position: "absolute",
  },
  text: {
    top: 53,
    left: 145,
    fontSize: 64,
    color: Color.grayscaleWhite,
    textAlign: "left",
    fontFamily: FontFamily.rubikRegular,
  },
  kg: {
    top: 100,
    left: 216,
  },
  janFebMar: {
    top: 303,
    left: 18,
  },
  groupInner: {
    top: 186,
    left: 318,
    width: 20,
    height: 20,
    position: "absolute",
  },
  rectangleParent: {
    top: 109,
    height: 350,
    width: 350,
    left: 26,
    position: "absolute",
  },
  rectangleView: {
    height: 84,
    width: 99,
    top: 0,
    left: 0,
  },
  target: {
    left: 0,
  },
  text1: {
    left: 9,
  },
  targetParent: {
    width: 47,
  },
  rectangleGroup: {
    width: 99,
    top: 0,
    left: 0,
    position: "absolute",
  },
  iphone1415Pro10Inner: {
    left: 277,
    top: 478,
    width: 99,
    position: "absolute",
  },
  groupChild1: {
    height: 84,
    width: 99,
    top: 0,
    left: 0,
  },
  text2: {
    left: 0,
  },
  changeParent: {
    width: 54,
  },
  groupView: {
    left: 157,
    top: 478,
    width: 99,
    position: "absolute",
  },
  iphone1415Pro10Item: {
    top: 600,
    left: 37,
    width: 219,
    height: 201,
  },
  groupChild2: {
    elevation: 4,
    shadowRadius: 4,
    width: 67,
    backgroundColor: Color.gray1,
    shadowOpacity: 1,
    shadowOffset: {
      width: 3,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    top: 0,
    borderRadius: Border.br_81xl,
    left: 0,
  },
  plusIcon: {
    top: 21,
    left: 21,
    width: 25,
    height: 25,
    position: "absolute",
    overflow: "hidden",
  },
  rectangleParent1: {
    top: 734,
    left: 300,
  },
  status: {
    top: 738,
    left: 123,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    color: Color.grayscaleWhite,
    fontFamily: FontFamily.rubikRegular,
    position: "absolute",
  },
  good: {
    top: 644,
    left: 79,
    fontSize: 48,
    color: "#6fcf97",
    textAlign: "left",
    fontFamily: FontFamily.rubikRegular,
  },
  groupChild3: {
    height: 84,
    width: 99,
    top: 0,
    left: 0,
  },
  now: {
    left: 5,
  },
  nowParent: {
    height: 56,
    width: 47,
    top: 14,
    left: 26,
    position: "absolute",
  },
  iphone1415Pro10Inner1: {
    left: 32,
    top: 478,
    width: 99,
    position: "absolute",
  },
  iphone1415Pro10: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro9;
