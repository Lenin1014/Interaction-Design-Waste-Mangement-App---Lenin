import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import GroupComponent4 from "../components/GroupComponent4";
import GroupComponent3 from "../components/GroupComponent3";
import { FontFamily, Padding, Border, Color, FontSize } from "../GlobalStyles";

const IPhone1415Pro5 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro11}>
      <Image
        style={styles.iphone1415Pro11Child}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island5.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <Text style={[styles.healthAndNews, styles.wrapperLayout]}>
        Health and News
      </Text>
      <Pressable
        style={[styles.wrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View style={styles.groupParent}>
        <GroupComponent4
          rectangle18={require("../assets/rectangle-18.png")}
          part230FirmsWhoDonatedRs3="Part 2: 30 firms who donated Rs 335 cr to BJP were also stung by I-T, ED"
          finance="finance"
        />
        <GroupComponent3 />
        <GroupComponent4
          rectangle18={require("../assets/rectangle-182.png")}
          part230FirmsWhoDonatedRs3="In Haldwani, journalist ‘nearly killed’, mob asks reporters to ‘show ..."
          finance="violence"
          propTop={264}
          propLeft={1}
          propWidth={65}
        />
      </View>
      <Text style={[styles.headlines, styles.headlinesTypo]}>Headlines</Text>
      <View style={[styles.rectangleParent, styles.rectangleLayout]}>
        <Image
          style={[styles.groupChild, styles.rectangleLayout]}
          contentFit="cover"
          source={require("../assets/rectangle-15.png")}
        />
        <View style={[styles.groundReportWrapper, styles.wrapperFlexBox]}>
          <Text style={styles.groundReport}>Ground report</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <LinearGradient
            style={[styles.groupItem, styles.groupLayout]}
            locations={[0, 1]}
            colors={["rgba(41, 45, 50, 0)", "#292d32"]}
          />
          <Text style={styles.marchFromShambhu}>
            March from Shambhu stalled, 1 from Punjab dead
          </Text>
          <Text style={[styles.jan32024By, styles.headlinesTypo]}>
            Jan 3,2024 by Basant Kumar
          </Text>
        </View>
      </View>
      <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
        <Image
          style={[styles.groupChild, styles.rectangleLayout]}
          contentFit="cover"
          source={require("../assets/rectangle-151.png")}
        />
        <View style={[styles.latestWrapper, styles.wrapperFlexBox]}>
          <Text style={styles.groundReport}>Latest</Text>
        </View>
        <View style={[styles.rectangleGroup, styles.groupLayout]}>
          <LinearGradient
            style={[styles.groupItem, styles.groupLayout]}
            locations={[0, 1]}
            colors={["rgba(41, 45, 50, 0)", "#292d32"]}
          />
          <Text style={styles.marchFromShambhu}>
            Farmers’ protests: Punjab farmer alleges he was ‘stuffed in sack,
            assaulted’ by Harya...
          </Text>
          <Text style={[styles.jan32024By, styles.headlinesTypo]}>
            Jan 3,2024 by Rajeev Shukla
          </Text>
        </View>
      </View>
      <Text style={[styles.groundReporting, styles.politicsTypo]}>
        Ground Reporting
      </Text>
      <Text style={[styles.politics, styles.politicsTypo]}>Politics</Text>
      <Text style={[styles.business, styles.politicsTypo]}>Business</Text>
      <View style={styles.groundReportingParent}>
        <Text style={[styles.groundReporting1, styles.economicTypo]}>
          Ground Reporting
        </Text>
        <Text style={[styles.business1, styles.economicTypo]}>Business</Text>
        <Text style={[styles.economic, styles.economicTypo]}>Economic</Text>
        <Text style={[styles.politics1, styles.economicTypo]}>Politics</Text>
        <View style={styles.forYouParent}>
          <Text style={styles.forYou}>For You</Text>
          <View style={styles.frameChild} />
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperLayout: {
    height: 23,
    position: "absolute",
  },
  headlinesTypo: {
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    left: 16,
    textAlign: "left",
    position: "absolute",
  },
  rectangleLayout: {
    height: 220,
    width: 314,
    position: "absolute",
  },
  wrapperFlexBox: {
    paddingVertical: Padding.p_9xs,
    paddingHorizontal: Padding.p_3xs,
    flexDirection: "row",
    borderRadius: Border.br_xl,
    left: 18,
    top: 10,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: Color.colorRed,
    height: 23,
    position: "absolute",
    overflow: "hidden",
  },
  groupLayout: {
    height: 83,
    width: 314,
    left: 0,
    position: "absolute",
  },
  politicsTypo: {
    color: Color.colorDarkgray_200,
    top: 415,
    fontFamily: FontFamily.interSemiBold,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    fontWeight: "600",
    position: "absolute",
  },
  economicTypo: {
    top: 2,
    color: Color.colorDarkgray_200,
    fontFamily: FontFamily.interSemiBold,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    fontWeight: "600",
    position: "absolute",
  },
  iphone1415Pro11Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  healthAndNews: {
    top: 74,
    left: 86,
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.labelColorLightPrimary,
    width: 267,
    textAlign: "left",
    fontWeight: "600",
    height: 23,
    fontSize: FontSize.size_5xl,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 22,
    top: 85,
    width: 14,
  },
  groupParent: {
    top: 419,
    width: 354,
    height: 386,
    left: 13,
    position: "absolute",
  },
  headlines: {
    top: 117,
    color: "#7b7878",
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
  },
  groupChild: {
    borderRadius: Border.br_mini,
    top: 0,
    left: 0,
  },
  groundReport: {
    fontSize: FontSize.size_xs,
    textAlign: "center",
    color: Color.grayscaleWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
  },
  groundReportWrapper: {
    width: 95,
  },
  groupItem: {
    borderBottomRightRadius: Border.br_mini,
    borderBottomLeftRadius: Border.br_mini,
    borderStyle: "solid",
    borderColor: Color.colorDimgray_100,
    borderBottomWidth: 1,
    backgroundColor: "transparent",
    top: 0,
  },
  marchFromShambhu: {
    top: 13,
    fontSize: FontSize.size_smi,
    width: 282,
    color: Color.grayscaleWhite,
    fontFamily: FontFamily.interExtraBold,
    fontWeight: "800",
    left: 16,
    textAlign: "left",
    position: "absolute",
  },
  jan32024By: {
    top: 55,
    fontSize: FontSize.size_3xs,
    color: Color.colorDarkgray_100,
  },
  rectangleGroup: {
    top: 137,
  },
  rectangleParent: {
    left: 335,
    top: 160,
    width: 314,
  },
  latestWrapper: {
    width: 52,
  },
  rectangleContainer: {
    top: 160,
    width: 314,
    left: 13,
  },
  groundReporting: {
    left: 91,
  },
  politics: {
    left: 233,
  },
  business: {
    left: 300,
  },
  groundReporting1: {
    left: 79,
  },
  business1: {
    left: 288,
  },
  economic: {
    left: 366,
  },
  politics1: {
    left: 221,
  },
  forYou: {
    color: Color.colorRed,
    fontFamily: FontFamily.interSemiBold,
    fontSize: FontSize.size_mini,
    textAlign: "center",
    fontWeight: "600",
  },
  frameChild: {
    borderTopLeftRadius: Border.br_11xs,
    borderTopRightRadius: Border.br_11xs,
    width: 71,
    height: 4,
    backgroundColor: Color.colorRed,
  },
  forYouParent: {
    top: 3,
    justifyContent: "center",
    alignItems: "center",
    left: 0,
    position: "absolute",
  },
  groundReportingParent: {
    top: 380,
    width: 353,
    height: 25,
    left: 16,
    position: "absolute",
  },
  iphone1415Pro11: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro5;
