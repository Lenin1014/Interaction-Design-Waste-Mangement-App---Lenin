import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import Datepicker from "../components/Datepicker";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const IPhone1415Pro4 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro9}>
      <Image
        style={styles.iphone1415Pro9Child}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <Image
        style={styles.image1Icon}
        contentFit="cover"
        source={require("../assets/image-11.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island4.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <Text
        style={[styles.wasteGet, styles.wrapperLayout]}
      >{`Waste & get points`}</Text>
      <Pressable
        style={[styles.wrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View style={[styles.iphone1415Pro9Inner, styles.datepickerParentLayout]}>
        <View style={[styles.datepickerParent, styles.groupChildPosition]}>
          <Datepicker />
          <View style={[styles.groupChild, styles.groupChildPosition]} />
          <Text style={[styles.text, styles.textFlexBox]}>70</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperLayout: {
    height: 23,
    position: "absolute",
  },
  datepickerParentLayout: {
    height: 496,
    width: 375,
  },
  groupChildPosition: {
    top: 0,
    position: "absolute",
  },
  textFlexBox: {
    textAlign: "left",
    color: Color.labelColorLightPrimary,
  },
  iphone1415Pro9Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  image1Icon: {
    left: 50,
    width: 295,
    height: 259,
    top: 74,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  wasteGet: {
    left: 86,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    width: 267,
    textAlign: "left",
    color: Color.labelColorLightPrimary,
    top: 74,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 22,
    top: 85,
    width: 14,
  },
  groupChild: {
    left: 58,
    shadowColor: "rgba(255, 255, 255, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    borderRadius: Border.br_xl,
    backgroundColor: Color.grayscaleWhite,
    width: 260,
    height: 75,
  },
  text: {
    top: 22,
    left: 167,
    fontSize: FontSize.size_17xl,
    fontFamily: FontFamily.robotoRegular,
    position: "absolute",
  },
  datepickerParent: {
    height: 496,
    width: 375,
    left: 0,
  },
  iphone1415Pro9Inner: {
    top: 329,
    left: 7,
    position: "absolute",
  },
  iphone1415Pro9: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro4;
