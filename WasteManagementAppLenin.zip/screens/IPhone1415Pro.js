import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { useNavigation } from "@react-navigation/native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { Color, Border, FontSize, FontFamily } from "../GlobalStyles";

const IPhone1415Pro = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro1}>
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <View style={styles.managementParent}>
        <Text style={[styles.management, styles.wasteFlexBox]}>MANAGEMENT</Text>
        <Text style={[styles.waste, styles.wastePosition]}>Waste</Text>
      </View>
      <Image
        style={styles.trash1Traced}
        contentFit="cover"
        source={require("../assets/trash-1-traced.png")}
      />
      <Pressable
        style={[styles.iphone1415Pro1Inner, styles.groupChildLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro1")}
      >
        <View style={[styles.groupChild, styles.groupChildLayout]} />
      </Pressable>
      <Text style={[styles.getStart, styles.wasteFlexBox]}>Get Start</Text>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island.png")}
        data={require("../assets/data.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  wasteFlexBox: {
    textAlign: "center",
    color: Color.grayscaleWhite,
    position: "absolute",
  },
  wastePosition: {
    top: 0,
    left: 0,
  },
  groupChildLayout: {
    height: 68,
    width: 342,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  management: {
    top: 44,
    left: 2,
    fontSize: FontSize.size_xl,
    letterSpacing: 6,
    fontFamily: FontFamily.poppinsBold,
    width: 201,
    fontWeight: "700",
    color: Color.grayscaleWhite,
  },
  waste: {
    fontSize: FontSize.size_17xl,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    height: 44,
    textAlign: "center",
    color: Color.grayscaleWhite,
    position: "absolute",
    width: 203,
  },
  managementParent: {
    top: 376,
    left: 94,
    height: 74,
    width: 203,
    position: "absolute",
  },
  trash1Traced: {
    height: "7.36%",
    width: "15.95%",
    top: "34.15%",
    right: "39.01%",
    bottom: "58.49%",
    left: "45.04%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  groupChild: {
    borderRadius: Border.br_mid_6,
    backgroundColor: Color.mainBlack,
    top: 0,
    left: 0,
  },
  iphone1415Pro1Inner: {
    top: 711,
    left: 23,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
  },
  getStart: {
    top: 730,
    left: 135,
    fontSize: FontSize.size_lg_8,
    lineHeight: 16,
    textTransform: "capitalize",
    fontFamily: FontFamily.interBold,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 123,
    height: 30,
    fontWeight: "700",
    color: Color.grayscaleWhite,
  },
  iphone1415Pro1: {
    backgroundColor: Color.colorForestgreen_100,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default IPhone1415Pro;
