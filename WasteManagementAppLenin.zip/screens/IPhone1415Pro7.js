import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import RatingScale from "../components/RatingScale";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const IPhone1415Pro7 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro13}>
      <Image
        style={styles.iphone1415Pro13Child}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island7.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <Text style={[styles.feedbackForm, styles.wrapperLayout]}>
        Feedback Form
      </Text>
      <Pressable
        style={[styles.wrapper, styles.wrapperLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro6")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View style={styles.ratingScale}>
        <RatingScale
          worstStyle={require("../assets/worst-style1.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style1.png")}
          neutral={require("../assets/neutral1.png")}
          goodStyle={require("../assets/good-style1.png")}
          loveItStyle={require("../assets/love-it-style1.png")}
          frame15={require("../assets/frame-151.png")}
          propMarginTop="unset"
          propPosition="absolute"
          propTop={20}
          propLeft={20}
          propColor="#105955"
          propColor1="#a5e0dd"
          propColor2="#a5e0dd"
          propColor3="#a5e0dd"
          propColor4="#a5e0dd"
          propWidth={350}
          propWidth1={57}
          propWidth2="unset"
          propWidth3={49}
          propAlignSelf="unset"
        />
        <RatingScale
          worstStyle={require("../assets/worst-style2.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style2.png")}
          neutral={require("../assets/neutral1.png")}
          goodStyle={require("../assets/good-style1.png")}
          loveItStyle={require("../assets/love-it-style1.png")}
          frame15={require("../assets/frame-152.png")}
          propMarginTop="unset"
          propPosition="absolute"
          propTop={160}
          propLeft={20}
          propColor="#a5e0dd"
          propColor1="#105955"
          propColor2="#a5e0dd"
          propColor3="#a5e0dd"
          propColor4="#a5e0dd"
          propWidth={350}
          propWidth1="unset"
          propWidth2={119}
          propWidth3="unset"
          propAlignSelf="stretch"
        />
        <RatingScale
          worstStyle={require("../assets/worst-style2.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style1.png")}
          neutral={require("../assets/neutral2.png")}
          goodStyle={require("../assets/good-style1.png")}
          loveItStyle={require("../assets/love-it-style1.png")}
          frame15={require("../assets/frame-153.png")}
          propMarginTop="unset"
          propPosition="absolute"
          propTop={300}
          propLeft={20}
          propColor="#a5e0dd"
          propColor1="#a5e0dd"
          propColor2="#105955"
          propColor3="#a5e0dd"
          propColor4="#a5e0dd"
          propWidth={350}
          propWidth1="unset"
          propWidth2={192}
          propWidth3="unset"
          propAlignSelf="stretch"
        />
        <RatingScale
          worstStyle={require("../assets/worst-style3.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style3.png")}
          neutral={require("../assets/neutral3.png")}
          goodStyle={require("../assets/good-style2.png")}
          loveItStyle={require("../assets/love-it-style2.png")}
          frame15={require("../assets/frame-154.png")}
          propMarginTop="unset"
          propPosition="absolute"
          propTop={440}
          propLeft={20}
          propColor="#a5e0dd"
          propColor1="#a5e0dd"
          propColor2="#a5e0dd"
          propColor3="#105955"
          propColor4="#a5e0dd"
          propWidth={350}
          propWidth1="unset"
          propWidth2={269}
          propWidth3="unset"
          propAlignSelf="stretch"
        />
        <RatingScale
          worstStyle={require("../assets/worst-style3.png")}
          itsJustFineStyle={require("../assets/its-just-fine-style3.png")}
          neutral={require("../assets/neutral3.png")}
          goodStyle={require("../assets/good-style3.png")}
          loveItStyle={require("../assets/love-it-style3.png")}
          frame15={require("../assets/frame-155.png")}
          propMarginTop="unset"
          propPosition="absolute"
          propTop={580}
          propLeft={20}
          propColor="#a5e0dd"
          propColor1="#a5e0dd"
          propColor2="#a5e0dd"
          propColor3="#a5e0dd"
          propColor4="#105955"
          propWidth={356}
          propWidth1="unset"
          propWidth2={356}
          propWidth3="unset"
          propAlignSelf="stretch"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperLayout: {
    height: 23,
    position: "absolute",
  },
  iphone1415Pro13Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    left: 0,
    width: 390,
    height: 34,
    position: "absolute",
  },
  feedbackForm: {
    top: 74,
    left: 86,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    width: 267,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    left: 22,
    top: 85,
    width: 14,
  },
  ratingScale: {
    top: 140,
    left: 7,
    borderRadius: Border.br_8xs,
    backgroundColor: "#edf9f1",
    borderStyle: "dashed",
    borderColor: "#9747ff",
    borderWidth: 1,
    width: 380,
    height: 661,
    position: "absolute",
    overflow: "hidden",
  },
  iphone1415Pro13: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro7;
