import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import GroupComponent1 from "../components/GroupComponent1";
import { useNavigation } from "@react-navigation/native";
import { FontFamily, Color, FontSize, Border } from "../GlobalStyles";

const IPhone1415Pro3 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro4}>
      <Image
        style={styles.iphone1415Pro4Child}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island3.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <GroupComponent1 />
      <View style={styles.iphone1415Pro4Item} />
      <Image
        style={[styles.magnifyingGlass1Icon, styles.searchPosition]}
        contentFit="cover"
        source={require("../assets/magnifyingglass-1.png")}
      />
      <Text style={[styles.search, styles.searchLayout]}>Search</Text>
      <Pressable
        style={styles.wrapper}
        onPress={() => navigation.navigate("IPhone1415Pro10")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/ellipse-10.png")}
        />
      </Pressable>
      <Text style={[styles.hiMrLeninContainer, styles.pointsTypo]}>
        <Text style={styles.hi}>Hi</Text>
        <Text style={styles.mrLeninPerera}>, Mr Lenin Perera !</Text>
      </Text>
      <Text style={styles.home}>Home</Text>
      <Pressable
        style={[styles.rectangleParent, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro4")}
      >
        <View style={styles.groupShadowBox} />
        <Image
          style={[styles.star11TracedTraced, styles.tracedLayout]}
          contentFit="cover"
          source={require("../assets/star-1-1-traced-traced.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.rectangleGroup, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro5")}
      >
        <View style={styles.groupShadowBox} />
        <Image
          style={[styles.heartBeat1Traced, styles.tracedPosition]}
          contentFit="cover"
          source={require("../assets/heartbeat-1-traced.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.rectangleContainer, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro8")}
      >
        <View style={styles.groupShadowBox} />
        <Image
          style={[styles.medal1Traced, styles.tracedPosition]}
          contentFit="cover"
          source={require("../assets/medal-1-traced.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.groupPressable, styles.rectangleGroupLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro6")}
      >
        <View style={styles.groupShadowBox} />
        <Image
          style={[styles.feedback1Traced, styles.tracedLayout]}
          contentFit="cover"
          source={require("../assets/feedback-1-traced.png")}
        />
      </Pressable>
      <Text style={styles.wasteGet}>{`Waste &
get Point`}</Text>
      <Text style={[styles.newsHealth, styles.feedbackTypo]}>News health</Text>
      <Text style={[styles.joinContest, styles.feedbackTypo]}>{`Join Contest 
& Win`}</Text>
      <Text style={[styles.feedback, styles.feedbackTypo]}>Feedback</Text>
      <Text style={[styles.points, styles.pointsTypo]}>Points</Text>
      <View style={[styles.iphone1415Pro4Inner, styles.pointsPosition]} />
      <Text style={[styles.myPoints, styles.textFlexBox]}>My Points</Text>
      <View style={[styles.groupView, styles.groupLayout]}>
        <View style={[styles.groupChild1, styles.groupLayout]} />
        <Text style={[styles.redeem, styles.redeemTypo]}>Redeem</Text>
      </View>
      <Image
        style={styles.vectorIcon}
        contentFit="cover"
        source={require("../assets/vector-5.png")}
      />
      <Image
        style={styles.rectangleIcon}
        contentFit="cover"
        source={require("../assets/rectangle-742.png")}
      />
      <Image
        style={styles.money4Icon}
        contentFit="cover"
        source={require("../assets/money-4.png")}
      />
      <Text style={[styles.totalPoints, styles.redeemTypo]}>Total Points</Text>
      <Text style={[styles.text, styles.textFlexBox]}>320</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  searchPosition: {
    height: 22,
    top: 87,
    position: "absolute",
  },
  searchLayout: {
    width: 65,
    textAlign: "left",
  },
  pointsTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  rectangleGroupLayout: {
    width: 64,
    top: 526,
    height: 69,
    position: "absolute",
  },
  tracedLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: "25.79%",
    position: "absolute",
    overflow: "hidden",
  },
  tracedPosition: {
    bottom: "23.69%",
    height: "47.67%",
    maxHeight: "100%",
    maxWidth: "100%",
    top: "28.63%",
    position: "absolute",
    overflow: "hidden",
  },
  feedbackTypo: {
    height: 16,
    top: 604,
    textAlign: "center",
    color: Color.colorDarkslategray_100,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    lineHeight: 15,
    fontSize: FontSize.size_sm,
    position: "absolute",
  },
  pointsPosition: {
    left: 20,
    position: "absolute",
  },
  textFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    display: "flex",
    lineHeight: 11,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    position: "absolute",
  },
  groupLayout: {
    width: 112,
    height: 34,
    position: "absolute",
  },
  redeemTypo: {
    fontSize: FontSize.size_base,
    lineHeight: 11,
    textAlign: "center",
    position: "absolute",
  },
  iphone1415Pro4Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  iphone1415Pro4Item: {
    top: 64,
    borderRadius: Border.br_lg,
    width: 335,
    height: 69,
    backgroundColor: Color.colorWhitesmoke_100,
    left: 32,
    position: "absolute",
  },
  magnifyingGlass1Icon: {
    width: 22,
    left: 151,
    height: 22,
    top: 87,
  },
  search: {
    left: 177,
    fontSize: FontSize.size_lg,
    fontWeight: "700",
    fontFamily: FontFamily.montserratBold,
    color: "#939393",
    height: 22,
    top: 87,
    position: "absolute",
    width: 65,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    top: 160,
    right: 26,
    width: 83,
    height: 70,
    position: "absolute",
  },
  hi: {
    color: "rgba(0, 0, 0, 0.43)",
  },
  mrLeninPerera: {
    color: Color.colorForestgreen_100,
  },
  hiMrLeninContainer: {
    top: 186,
    fontSize: FontSize.size_xl,
    width: 291,
    height: 33,
    left: 20,
    position: "absolute",
    textAlign: "left",
    fontWeight: "600",
  },
  home: {
    top: 137,
    color: Color.labelColorLightPrimary,
    height: 23,
    width: 73,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textAlign: "left",
    left: 151,
    position: "absolute",
  },
  groupShadowBox: {
    backgroundColor: Color.grayscaleWhite,
    borderRadius: Border.br_2xs,
    shadowOpacity: 1,
    elevation: 15,
    shadowRadius: 15,
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowColor: "rgba(0, 0, 0, 0.1)",
    top: 0,
    width: 64,
    height: 69,
    left: 0,
    position: "absolute",
  },
  star11TracedTraced: {
    height: "44.48%",
    bottom: "26.89%",
    right: "25.79%",
    top: "28.63%",
    width: "48.43%",
    maxWidth: "100%",
  },
  rectangleParent: {
    left: 27,
  },
  heartBeat1Traced: {
    width: "61.32%",
    left: "19.34%",
    right: "19.34%",
  },
  rectangleGroup: {
    left: 116,
  },
  medal1Traced: {
    left: "25.79%",
    height: "47.67%",
    right: "25.79%",
    width: "48.43%",
  },
  rectangleContainer: {
    left: 206,
  },
  feedback1Traced: {
    height: "52.33%",
    width: "54.87%",
    top: "23.84%",
    bottom: "23.84%",
    right: "19.34%",
  },
  groupPressable: {
    left: 295,
  },
  wasteGet: {
    top: 607,
    height: 32,
    textAlign: "center",
    color: Color.colorDarkslategray_100,
    lineHeight: 15,
    fontSize: FontSize.size_sm,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    left: 26,
    width: 65,
    position: "absolute",
  },
  newsHealth: {
    left: 110,
    width: 73,
    top: 604,
  },
  joinContest: {
    left: 181,
    width: 114,
  },
  feedback: {
    width: 72,
    left: 295,
  },
  points: {
    top: 236,
    fontSize: FontSize.size_mid,
    color: Color.colorDimgray_200,
    height: 24,
    left: 20,
    position: "absolute",
    width: 65,
    textAlign: "left",
  },
  iphone1415Pro4Inner: {
    backgroundColor: "rgba(70, 159, 39, 0.85)",
    width: 115,
    borderRadius: Border.br_sm_5,
    top: 268,
    height: 34,
  },
  myPoints: {
    top: 280,
    fontSize: FontSize.size_mini,
    color: Color.grayscaleWhite,
    width: 93,
    height: 10,
    alignItems: "center",
    display: "flex",
    lineHeight: 11,
    left: 32,
  },
  groupChild1: {
    borderRadius: Border.br_sm_5,
    top: 0,
    width: 112,
    backgroundColor: Color.colorWhitesmoke_100,
    left: 0,
  },
  redeem: {
    top: 10,
    left: 18,
    color: "#5e5e5e",
    width: 79,
    height: 15,
    fontFamily: FontFamily.poppinsMedium,
    fontWeight: "500",
    fontSize: FontSize.size_base,
  },
  groupView: {
    left: 145,
    top: 268,
  },
  vectorIcon: {
    top: 148,
    width: 14,
    left: 26,
    height: 23,
    position: "absolute",
  },
  rectangleIcon: {
    top: 317,
    left: 34,
    borderRadius: Border.br_xs,
    width: 326,
    height: 151,
    position: "absolute",
  },
  money4Icon: {
    top: 331,
    left: 163,
    width: 62,
    height: 65,
    position: "absolute",
  },
  totalPoints: {
    top: 405,
    left: 135,
    color: Color.text,
    width: 120,
    height: 11,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  text: {
    top: 427,
    left: 168,
    color: "#202221",
    width: 57,
    height: 14,
    fontSize: FontSize.size_5xl,
    alignItems: "center",
    display: "flex",
    lineHeight: 11,
  },
  iphone1415Pro4: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro3;
