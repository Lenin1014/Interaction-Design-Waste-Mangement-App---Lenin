import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Image } from "expo-image";
import GroupComponent6 from "../components/GroupComponent6";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { Color, FontSize, Border, FontFamily } from "../GlobalStyles";

const IPhone1415Pro11 = () => {
  return (
    <View style={styles.iphone1415Pro8}>
      <View style={styles.homeindicator}>
        <View style={[styles.homeIndicator, styles.vectorIconLayout]} />
      </View>
      <GroupComponent6 />
      <Text style={[styles.logOut, styles.logOutClr]}>Log Out</Text>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island11.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <Image
        style={styles.iphone1415Pro8Child}
        contentFit="cover"
        source={require("../assets/ellipse-101.png")}
      />
      <View style={[styles.iphone1415Pro8Item, styles.rectangleLayout]} />
      <View style={styles.iphone1415Pro8Inner} />
      <View style={[styles.rectangleParent, styles.rectangleLayout]}>
        <View style={[styles.groupChild, styles.groupPosition]} />
        <Text style={styles.leninperera7gmailcom}>leninperera7@gmail.com</Text>
      </View>
      <View style={[styles.rectangleGroup, styles.rectangleLayout]}>
        <View style={[styles.groupChild, styles.groupPosition]} />
        <Text style={[styles.leninMerash, styles.leninMerashPosition]}>
          Lenin Merash
        </Text>
      </View>
      <Text style={[styles.perera, styles.maleTypo]}>Perera</Text>
      <Text style={[styles.male, styles.maleTypo]}>Male</Text>
      <Text style={[styles.updateInformation, styles.updateClr]}>
        Update Information
      </Text>
      <Text style={[styles.updateAnAccount, styles.updateClr]}>
        Update an account
      </Text>
      <Image
        style={[styles.vectorIcon, styles.vectorIconLayout]}
        contentFit="cover"
        source={require("../assets/vector-4.png")}
      />
      <View style={[styles.rectangleContainer, styles.rectangleLayout]}>
        <View style={[styles.groupInner, styles.groupPosition]} />
        <Text style={[styles.updateProfile, styles.updateTypo]}>
          Update Profile
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  vectorIconLayout: {
    height: 5,
    position: "absolute",
  },
  logOutClr: {
    color: Color.grayscaleWhite,
    fontSize: FontSize.size_xl,
  },
  rectangleLayout: {
    height: 42,
    width: 305,
    position: "absolute",
  },
  groupPosition: {
    top: 0,
    height: 42,
    width: 305,
    borderRadius: Border.br_8xl,
    left: 0,
    position: "absolute",
  },
  leninMerashPosition: {
    height: 21,
    textAlign: "left",
    top: 11,
    position: "absolute",
  },
  maleTypo: {
    left: 79,
    height: 21,
    textAlign: "left",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  updateClr: {
    color: Color.colorGray_400,
    textAlign: "left",
    position: "absolute",
  },
  updateTypo: {
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  logOut: {
    top: 674,
    left: 132,
    lineHeight: 11,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 160,
    height: 23,
    position: "absolute",
  },
  iphone1415Pro8Child: {
    top: 88,
    right: 87,
    width: 210,
    height: 206,
    position: "absolute",
  },
  iphone1415Pro8Item: {
    top: 462,
    backgroundColor: Color.colorLightgray_200,
    borderRadius: Border.br_8xl,
    height: 42,
    left: 51,
  },
  iphone1415Pro8Inner: {
    top: 521,
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 4,
    elevation: 4,
    shadowOpacity: 1,
    backgroundColor: "rgba(255, 255, 255, 0.21)",
    height: 43,
    width: 305,
    borderRadius: Border.br_8xl,
    left: 51,
    position: "absolute",
  },
  groupChild: {
    backgroundColor: Color.colorLightgray_200,
  },
  leninperera7gmailcom: {
    width: 257,
    height: 24,
    textAlign: "left",
    top: 11,
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_base,
    left: 28,
    position: "absolute",
  },
  rectangleParent: {
    top: 579,
    left: 51,
    height: 42,
  },
  leninMerash: {
    width: 142,
    color: Color.labelColorLightPrimary,
    fontSize: FontSize.size_base,
    left: 28,
    height: 21,
    fontFamily: FontFamily.poppinsRegular,
  },
  rectangleGroup: {
    top: 402,
    left: 51,
    height: 42,
  },
  perera: {
    top: 472,
    width: 85,
  },
  male: {
    top: 532,
    width: 154,
  },
  updateInformation: {
    top: 309,
    left: 75,
    fontSize: FontSize.size_5xl,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
  },
  updateAnAccount: {
    top: 362,
    left: 56,
    fontSize: FontSize.size_xs,
    width: 128,
    height: 33,
    fontFamily: FontFamily.poppinsRegular,
    color: Color.colorGray_400,
  },
  vectorIcon: {
    top: 542,
    left: 326,
    width: 10,
  },
  groupInner: {
    backgroundColor: Color.colorForestgreen_100,
  },
  updateProfile: {
    left: 119,
    width: 116,
    height: 21,
    textAlign: "left",
    top: 11,
    position: "absolute",
    color: Color.grayscaleWhite,
    fontSize: FontSize.size_xl,
  },
  rectangleContainer: {
    top: 655,
    left: 54,
  },
  iphone1415Pro8: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default IPhone1415Pro11;
