import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const IPhone1415Pro8 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro14}>
      <Image
        style={styles.iphone1415Pro14Child}
        contentFit="cover"
        source={require("../assets/vector-11.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island8.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <Text style={styles.joinContast}>{`Join Contast & Win`}</Text>
      <Pressable
        style={[styles.wrapper, styles.wrapperPosition]}
        onPress={() => navigation.navigate("IPhone1415Pro3")}
      >
        <Image
          style={styles.icon}
          contentFit="cover"
          source={require("../assets/vector-5.png")}
        />
      </Pressable>
      <View
        style={[styles.iphone1415Pro14Item, styles.frameEdgeHighlightShadowBox]}
      />
      <View
        style={[styles.frameEdgeHighlight, styles.frameEdgeHighlightShadowBox]}
      />
      <View style={[styles.iphone1415Pro14Inner, styles.rectangleViewLayout]} />
      <View style={[styles.rectangleView, styles.rectangleViewLayout]} />
      <View style={styles.iphone1415Pro14Child1} />
      <View style={[styles.frameEdgeHighlight1, styles.frameShadowBox]} />
      <View
        style={[styles.frameEdgeHighlight2, styles.clearsAnyObjectLayout]}
      />
      <LinearGradient
        style={[styles.frameEdgeHighlight3, styles.frameBg]}
        locations={[0, 0.21, 0.94]}
        colors={["#b0d44f", "#628f30", "#365914"]}
      />
      <LinearGradient
        style={[styles.frameEdgeHighlight4, styles.frameBg]}
        locations={[0, 1]}
        colors={["#a1ca3d", "#5c8526"]}
      />
      <View style={[styles.frameEdgeHighlight5, styles.frameShadowBox]} />
      <View style={styles.frameEdgeHighlight6} />
      <Text style={[styles.claim, styles.claimTypo]}>Claim</Text>
      <View style={styles.iphone1415Pro14Child2} />
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-1.png")}
      />
      <Image
        style={styles.iphone1415Pro14Child3}
        contentFit="cover"
        source={require("../assets/ellipse-2.png")}
      />
      <Text style={[styles.clearsAnyObject, styles.claimTypo]}>
        Clears any object on the board
      </Text>
      <Image
        style={styles.iconLayout}
        contentFit="cover"
        source={require("../assets/banner.png")}
      />
      <Image
        style={[styles.maskGroupIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/mask-group.png")}
      />
      <Image
        style={[styles.maskGroupIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/banner-trim-btm.png")}
      />
      <Image
        style={[styles.maskGroupIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/banner-trim.png")}
      />
      <Image
        style={styles.frameIcon}
        contentFit="cover"
        source={require("../assets/frame.png")}
      />
      <Image
        style={styles.f1324913B9f584de536866ff1Icon}
        contentFit="cover"
        source={require("../assets/97803723f1324913b9f584de536866ff-1.png")}
      />
      <Image
        style={styles.subtractIcon}
        contentFit="cover"
        source={require("../assets/subtract.png")}
      />
      <Image
        style={styles.subtractIcon1}
        contentFit="cover"
        source={require("../assets/subtract1.png")}
      />
      <Image
        style={styles.subtractIcon2}
        contentFit="cover"
        source={require("../assets/subtract2.png")}
      />
      <Image
        style={styles.subtractIcon3}
        contentFit="cover"
        source={require("../assets/subtract3.png")}
      />
      <Image
        style={styles.subtractIcon4}
        contentFit="cover"
        source={require("../assets/subtract4.png")}
      />
      <Image
        style={styles.subtractIcon5}
        contentFit="cover"
        source={require("../assets/subtract5.png")}
      />
      <Image
        style={styles.subtractIcon6}
        contentFit="cover"
        source={require("../assets/subtract6.png")}
      />
      <Image
        style={styles.subtractIcon7}
        contentFit="cover"
        source={require("../assets/subtract7.png")}
      />
      <Image
        style={styles.subtractIcon2}
        contentFit="cover"
        source={require("../assets/subtract2.png")}
      />
      <Image
        style={styles.subtractIcon3}
        contentFit="cover"
        source={require("../assets/subtract8.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  wrapperPosition: {
    left: 22,
    position: "absolute",
  },
  frameEdgeHighlightShadowBox: {
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 14,
    },
    position: "absolute",
  },
  rectangleViewLayout: {
    height: 442,
    width: 301,
    borderRadius: Border.br_13xl,
    left: 51,
    top: 258,
    borderStyle: "solid",
    position: "absolute",
  },
  frameShadowBox: {
    width: 233,
    left: 85,
    backgroundColor: Color.colorDarkslateblue_100,
    shadowColor: "rgba(61, 112, 201, 0.4)",
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 14,
    },
    position: "absolute",
  },
  clearsAnyObjectLayout: {
    width: 193,
    left: 105,
  },
  frameBg: {
    backgroundColor: "transparent",
    position: "absolute",
  },
  claimTypo: {
    textShadowRadius: 0,
    textShadowOffset: {
      width: 0,
      height: 1,
    },
    fontFamily: FontFamily.mikadoBoldDEMO,
    position: "absolute",
  },
  iconLayout: {
    height: 126,
    width: 354,
  },
  iphone1415Pro14Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    left: 0,
    width: 390,
    height: 34,
    position: "absolute",
  },
  joinContast: {
    top: 74,
    left: 86,
    fontSize: FontSize.size_5xl,
    fontWeight: "600",
    fontFamily: FontFamily.poppinsSemiBold,
    color: Color.labelColorLightPrimary,
    width: 267,
    height: 53,
    textAlign: "left",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  wrapper: {
    top: 85,
    width: 14,
    height: 23,
  },
  iphone1415Pro14Item: {
    top: 246,
    left: 38,
    shadowColor: "#2a4563",
    borderRadius: 40,
    backgroundColor: "#2e5a9f",
    width: 326,
    height: 466,
  },
  frameEdgeHighlight: {
    top: 255,
    left: 48,
    shadowColor: "#3d70c9",
    borderRadius: 35,
    backgroundColor: "#001e4d",
    width: 307,
    height: 448,
  },
  iphone1415Pro14Inner: {
    borderColor: "#d6ad00",
    borderWidth: 10,
  },
  rectangleView: {
    borderColor: "#ca702c",
    borderWidth: 5,
  },
  iphone1415Pro14Child1: {
    top: 273,
    left: 66,
    borderRadius: 19,
    backgroundColor: "#2c519f",
    borderColor: "rgba(112, 203, 255, 0.11)",
    borderWidth: 2,
    width: 270,
    height: 412,
    borderStyle: "solid",
    position: "absolute",
  },
  frameEdgeHighlight1: {
    top: 525,
    borderRadius: 6,
    height: 54,
  },
  frameEdgeHighlight2: {
    top: 590,
    borderRadius: 14,
    height: 83,
    backgroundColor: Color.colorDarkslateblue_100,
    shadowColor: "rgba(61, 112, 201, 0.4)",
    left: 105,
    shadowOpacity: 1,
    elevation: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 14,
    },
    position: "absolute",
  },
  frameEdgeHighlight3: {
    top: 592,
    left: 107,
    width: 189,
    height: 79,
    borderRadius: Border.br_xs,
  },
  frameEdgeHighlight4: {
    top: 600,
    left: 116,
    borderRadius: Border.br_5xs,
    width: 170,
    height: 63,
  },
  frameEdgeHighlight5: {
    top: 309,
    borderRadius: Border.br_xl,
    height: 206,
  },
  frameEdgeHighlight6: {
    top: 312,
    left: 88,
    borderRadius: Border.br_lg,
    backgroundColor: "#f6edc6",
    width: 226,
    height: 199,
    position: "absolute",
  },
  claim: {
    top: 604,
    left: 148,
    fontSize: 36,
    letterSpacing: -0.9,
    width: 102,
    height: 55,
    textShadowColor: "#3c5511",
    textAlign: "left",
  },
  iphone1415Pro14Child2: {
    top: 318,
    left: 94,
    width: 214,
    height: 188,
    borderRadius: Border.br_xs,
    position: "absolute",
  },
  ellipseIcon: {
    top: 606,
    left: 265,
    width: 16,
    height: 13,
    position: "absolute",
  },
  iphone1415Pro14Child3: {
    top: 608,
    left: 255,
    width: 8,
    height: 4,
    position: "absolute",
  },
  clearsAnyObject: {
    top: 532,
    fontSize: FontSize.size_base,
    letterSpacing: -0.2,
    lineHeight: 19,
    textAlign: "center",
    textShadowColor: "#121d00",
    height: 38,
    width: 193,
    left: 105,
  },
  maskGroupIcon: {
    top: 210,
    left: 22,
    position: "absolute",
  },
  frameIcon: {
    top: 224,
    left: 110,
    width: 171,
    height: 61,
    position: "absolute",
  },
  f1324913B9f584de536866ff1Icon: {
    top: 320,
    left: 106,
    width: 186,
    height: 179,
    position: "absolute",
  },
  subtractIcon: {
    width: 28,
    height: 27,
  },
  subtractIcon1: {
    width: 33,
    height: 32,
  },
  subtractIcon2: {
    width: 50,
    height: 48,
  },
  subtractIcon3: {
    width: 25,
    height: 24,
  },
  subtractIcon4: {
    width: 27,
    height: 26,
  },
  subtractIcon5: {
    width: 26,
    height: 25,
  },
  subtractIcon6: {
    width: 39,
    height: 37,
  },
  subtractIcon7: {
    width: 40,
    height: 38,
  },
  iphone1415Pro14: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro8;
