import * as React from "react";
import { StyleSheet, View, Text, ImageBackground } from "react-native";
import { Image } from "expo-image";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import GroupComponent7 from "../components/GroupComponent7";
import BottomDrawer from "../components/BottomDrawer";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const IPhone1415Pro12 = () => {
  return (
    <View style={styles.iphone1415Pro6}>
      <View style={styles.homeindicator}>
        <View style={[styles.homeIndicator, styles.frameIconPosition]} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island12.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <GroupComponent7 />
      <BottomDrawer />
      <View style={styles.topDrawer}>
        <Image
          style={[styles.actionFlash, styles.actionLayout]}
          contentFit="cover"
          source={require("../assets/action--flash.png")}
        />
        <Image
          style={[styles.actionLivePhoto, styles.actionLayout]}
          contentFit="cover"
          source={require("../assets/action--live-photo.png")}
        />
        <Image
          style={[styles.actionCollapse, styles.frameIconPosition]}
          contentFit="cover"
          source={require("../assets/action--collapse.png")}
        />
      </View>
      <Text style={styles.materialRecognizer}>Material recognizer</Text>
      <ImageBackground
        style={[styles.frameIcon, styles.frameIconPosition]}
        resizeMode="cover"
        source={require("../assets/frame1.png")}
      >
        <View style={[styles.frameChild, styles.frameLayout]} />
        <Text style={[styles.plastic, styles.paperTypo]}> plastic</Text>
        <Image
          style={styles.frameItem}
          contentFit="cover"
          source={require("../assets/arrow-1.png")}
        />
        <View style={[styles.frameInner, styles.frameLayout]} />
        <Text style={[styles.paper, styles.paperTypo]}>Paper</Text>
        <Image
          style={styles.arrowIcon}
          contentFit="cover"
          source={require("../assets/arrow-2.png")}
        />
      </ImageBackground>
    </View>
  );
};

const styles = StyleSheet.create({
  frameIconPosition: {
    left: "50%",
    position: "absolute",
  },
  actionLayout: {
    height: 25,
    width: 25,
    top: 41,
    position: "absolute",
  },
  frameLayout: {
    borderRadius: Border.br_lg_5,
    position: "absolute",
  },
  paperTypo: {
    alignItems: "center",
    display: "flex",
    color: Color.grayscaleWhite,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    textTransform: "uppercase",
    lineHeight: 16,
    fontSize: FontSize.size_sm,
    textAlign: "left",
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    borderRadius: Border.br_81xl,
  },
  homeindicator: {
    top: 801,
    left: 0,
    width: 390,
    height: 34,
    position: "absolute",
  },
  actionFlash: {
    left: 12,
    borderRadius: Border.br_81xl,
    overflow: "hidden",
  },
  actionLivePhoto: {
    right: 13,
  },
  actionCollapse: {
    marginLeft: -13.5,
    top: 40,
    width: 28,
    height: 28,
    borderRadius: Border.br_81xl,
    overflow: "hidden",
  },
  topDrawer: {
    top: 123,
    right: 0,
    left: -8,
    backgroundColor: Color.colorGray_500,
    height: 78,
    position: "absolute",
    overflow: "hidden",
  },
  materialRecognizer: {
    top: 76,
    left: 97,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorDimgray_200,
    textAlign: "left",
    position: "absolute",
  },
  frameChild: {
    top: 178,
    left: 37,
    backgroundColor: "rgba(249, 158, 52, 0.84)",
    width: 125,
    height: 32,
  },
  plastic: {
    top: 184,
    left: 63,
    width: 110,
    height: 26,
  },
  frameItem: {
    top: 199,
    left: 162,
    width: 49,
    height: 3,
    position: "absolute",
  },
  frameInner: {
    top: 114,
    left: 261,
    backgroundColor: "rgba(70, 161, 246, 0.88)",
    width: 127,
    height: 37,
  },
  paper: {
    top: 117,
    left: 300,
    width: 112,
    height: 30,
  },
  arrowIcon: {
    top: 159,
    left: 211,
    width: 107,
    height: 84,
    position: "absolute",
  },
  frameIcon: {
    marginTop: -224,
    marginLeft: -196.5,
    top: "50%",
    width: 393,
    height: 432,
  },
  iphone1415Pro6: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default IPhone1415Pro12;
