import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text, Pressable } from "react-native";
import GroupComponent5 from "../components/GroupComponent5";
import { useNavigation } from "@react-navigation/native";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const IPhone1415Pro10 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro5}>
      <Image
        style={styles.iphone1415Pro5Child}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <View style={styles.iphone1415Pro5Item} />
      <View style={styles.homeindicator}>
        <View style={[styles.homeIndicator, styles.homeIndicatorBg]} />
      </View>
      <GroupComponent5 />
      <View style={[styles.iphone1415Pro5Inner, styles.homeIndicatorBg]} />
      <Text style={[styles.firstName, styles.nameFlexBox]}>First Name</Text>
      <Text style={[styles.gender, styles.nameFlexBox]}>Gender</Text>
      <Text style={[styles.email, styles.nameFlexBox]}>Email</Text>
      <Text style={[styles.lastName, styles.nameFlexBox]}>Last Name</Text>
      <Text style={[styles.leninMerash, styles.maleTypo]}>Lenin Merash</Text>
      <Text style={[styles.perera, styles.maleTypo]}>Perera</Text>
      <Text style={[styles.leninperera7gmailcom, styles.maleTypo]}>
        Leninperera7@gmail.com
      </Text>
      <Pressable
        style={[styles.rectangleParent, styles.groupChildLayout]}
        onPress={() => navigation.navigate("IPhone1415Pro11")}
      >
        <View style={[styles.groupChild, styles.groupChildPosition]} />
        <Text style={[styles.updateProfile, styles.nameFlexBox]}>
          Update Profile
        </Text>
      </Pressable>
      <Text style={[styles.logOut, styles.nameFlexBox]}>Log Out</Text>
      <Image
        style={[styles.rectangleIcon, styles.groupChildPosition]}
        contentFit="cover"
        source={require("../assets/rectangle-735.png")}
      />
      <Image
        style={styles.ellipseIcon}
        contentFit="cover"
        source={require("../assets/ellipse-9.png")}
      />
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island10.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <Text style={[styles.male, styles.maleTypo]}>Male</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  homeIndicatorBg: {
    backgroundColor: Color.labelColorLightPrimary,
    position: "absolute",
  },
  nameFlexBox: {
    textAlign: "center",
    lineHeight: 11,
    position: "absolute",
  },
  maleTypo: {
    color: Color.colorDarkslategray_200,
    textAlign: "center",
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    lineHeight: 11,
    fontSize: FontSize.size_base,
    position: "absolute",
  },
  groupChildLayout: {
    height: 41,
    width: 276,
  },
  groupChildPosition: {
    top: 0,
    left: 0,
    position: "absolute",
  },
  iphone1415Pro5Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  iphone1415Pro5Item: {
    top: 374,
    left: 4,
    backgroundColor: "rgba(220, 233, 218, 0.49)",
    width: 385,
    height: 205,
    borderRadius: Border.br_2xs,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    width: 134,
    height: 5,
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  iphone1415Pro5Inner: {
    top: 661,
    left: 47,
    width: 311,
    height: 48,
    borderRadius: Border.br_2xs,
  },
  firstName: {
    top: 400,
    left: 50,
    width: 98,
    height: 14,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    textAlign: "center",
    lineHeight: 11,
  },
  gender: {
    left: 18,
    width: 133,
    top: 494,
    height: 14,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    textAlign: "center",
    lineHeight: 11,
  },
  email: {
    top: 544,
    left: 55,
    width: 51,
    height: 14,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    textAlign: "center",
    lineHeight: 11,
  },
  lastName: {
    top: 441,
    left: 49,
    width: 97,
    height: 15,
    color: Color.colorGray_200,
    fontFamily: FontFamily.poppinsSemiBold,
    fontWeight: "600",
    fontSize: FontSize.size_base,
    textAlign: "center",
    lineHeight: 11,
  },
  leninMerash: {
    top: 396,
    left: 234,
    width: 125,
    height: 14,
  },
  perera: {
    top: 437,
    left: 290,
    width: 60,
    height: 15,
  },
  leninperera7gmailcom: {
    top: 547,
    left: 129,
    width: 236,
    height: 14,
  },
  groupChild: {
    borderRadius: Border.br_5xs,
    backgroundColor: "#f3f3f3",
    height: 41,
    width: 276,
  },
  updateProfile: {
    top: 15,
    left: 88,
    fontSize: FontSize.size_mini,
    fontWeight: "800",
    fontFamily: FontFamily.poppinsExtraBold,
    color: "#4a4a4a",
    lineHeight: 11,
    textAlign: "center",
  },
  rectangleParent: {
    top: 606,
    left: 62,
    position: "absolute",
  },
  logOut: {
    top: 674,
    left: 132,
    fontSize: FontSize.size_xl,
    fontWeight: "700",
    fontFamily: FontFamily.poppinsBold,
    color: Color.grayscaleWhite,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 160,
    height: 23,
    lineHeight: 11,
    textAlign: "center",
  },
  rectangleIcon: {
    width: 393,
    height: 260,
  },
  ellipseIcon: {
    top: 124,
    right: 155,
    width: 92,
    height: 104,
    position: "absolute",
  },
  male: {
    left: 309,
    top: 494,
  },
  iphone1415Pro5: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default IPhone1415Pro10;
