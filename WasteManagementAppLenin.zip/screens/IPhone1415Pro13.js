import * as React from "react";
import { StyleSheet, View, Pressable, Text } from "react-native";
import { Image } from "expo-image";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { useNavigation } from "@react-navigation/native";
import TodayWrapper from "../components/TodayWrapper";
import { Border, Color, FontFamily, FontSize } from "../GlobalStyles";

const IPhone1415Pro13 = () => {
  const navigation = useNavigation();

  return (
    <View style={styles.iphone1415Pro7}>
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island13.png")}
        data={require("../assets/data1.png")}
        batteryMarginLeft={-199.5}
      />
      <View style={[styles.rectangleParent, styles.groupChildLayout]}>
        <View style={[styles.groupChild, styles.groupChildLayout]} />
        <Pressable
          style={styles.house11Traced}
          onPress={() => navigation.navigate("IPhone1415Pro3")}
        >
          <Image
            style={[styles.icon, styles.tracedLayout]}
            contentFit="cover"
            source={require("../assets/house-1-1-traced2.png")}
          />
        </Pressable>
        <Text style={styles.home}>Home</Text>
        <View style={[styles.profileParent, styles.profileLayout]}>
          <Text style={[styles.profile, styles.profileLayout]}>Profile</Text>
          <Image
            style={[styles.group1364Traced, styles.tracedLayout]}
            contentFit="cover"
            source={require("../assets/group-1364-traced.png")}
          />
        </View>
        <View style={[styles.binSelectorWrapper, styles.binLayout]}>
          <Text style={[styles.binSelector, styles.binLayout]}>
            Bin selector
          </Text>
        </View>
        <View style={[styles.groupWrapper, styles.groupLayout]}>
          <View style={[styles.groupParent, styles.groupLayout]}>
            <View
              style={[styles.notificationWrapper, styles.notificationLayout]}
            >
              <Text style={[styles.notification, styles.notificationLayout]}>
                Notification
              </Text>
            </View>
            <Image
              style={[styles.notification1Traced, styles.tracedLayout]}
              contentFit="cover"
              source={require("../assets/notification-1-traced2.png")}
            />
            <View style={[styles.ellipseParent, styles.groupItemPosition]}>
              <Image
                style={[styles.groupItem, styles.groupItemPosition]}
                contentFit="cover"
                source={require("../assets/ellipse-37.png")}
              />
              <Text style={[styles.text, styles.textTypo]}>2</Text>
            </View>
          </View>
        </View>
        <Pressable
          style={styles.camera}
          onPress={() => navigation.navigate("IPhone1415Pro12")}
        >
          <Image
            style={[styles.icon1, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/camera3.png")}
          />
        </Pressable>
      </View>
      <Text style={[styles.notifications, styles.textTypo]}>Notifications</Text>
      <TodayWrapper />
    </View>
  );
};

const styles = StyleSheet.create({
  groupChildLayout: {
    height: 75,
    width: 384,
    position: "absolute",
  },
  tracedLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  profileLayout: {
    width: 59,
    position: "absolute",
  },
  binLayout: {
    width: 83,
    position: "absolute",
  },
  groupLayout: {
    height: 67,
    width: 132,
    top: 0,
    position: "absolute",
  },
  notificationLayout: {
    width: 132,
    height: 17,
    left: 0,
    position: "absolute",
  },
  groupItemPosition: {
    width: 29,
    top: 0,
    position: "absolute",
  },
  textTypo: {
    fontWeight: "700",
    position: "absolute",
  },
  iconLayout: {
    height: "100%",
    width: "100%",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  groupChild: {
    shadowColor: "rgba(0, 0, 0, 0.25)",
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowRadius: 12,
    elevation: 12,
    shadowOpacity: 1,
    borderRadius: Border.br_xs,
    backgroundColor: Color.grayscaleWhite,
    top: 0,
    left: 0,
  },
  icon: {
    height: "100%",
    width: "100%",
  },
  house11Traced: {
    left: "7.47%",
    top: "16%",
    right: "82.14%",
    bottom: "33.33%",
    width: "10.39%",
    height: "50.67%",
    position: "absolute",
  },
  home: {
    left: 29,
    width: 63,
    height: 17,
    textAlign: "left",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    top: 50,
    position: "absolute",
  },
  profile: {
    top: 38,
    height: 21,
    textAlign: "left",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    left: 0,
  },
  group1364Traced: {
    height: "54.58%",
    width: "74.24%",
    top: "0%",
    right: "24.92%",
    bottom: "45.42%",
    left: "0.84%",
    position: "absolute",
  },
  profileParent: {
    top: 11,
    left: 317,
    height: 59,
  },
  binSelector: {
    textAlign: "left",
    color: Color.labelColorLightPrimary,
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    left: 0,
    top: 0,
  },
  binSelectorWrapper: {
    top: 49,
    left: 202,
    height: 21,
  },
  notification: {
    color: Color.colorForestgreen_100,
    textAlign: "left",
    fontFamily: FontFamily.poppinsRegular,
    fontSize: FontSize.size_sm,
    width: 132,
    top: 0,
  },
  notificationWrapper: {
    width: 132,
    top: 50,
  },
  notification1Traced: {
    height: "57.16%",
    width: "24.3%",
    top: "15.67%",
    right: "59.5%",
    bottom: "27.16%",
    left: "16.2%",
    position: "absolute",
  },
  groupItem: {
    height: 24,
    left: 0,
  },
  text: {
    top: 2,
    left: 6,
    fontSize: FontSize.size_smi,
    fontFamily: FontFamily.nunitoBold,
    color: Color.grayscaleWhite,
    textAlign: "center",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    width: 13,
    height: 23,
  },
  ellipseParent: {
    left: 42,
    height: 25,
  },
  groupParent: {
    left: 0,
  },
  groupWrapper: {
    left: 97,
  },
  icon1: {
    overflow: "hidden",
  },
  camera: {
    left: 219,
    top: 6,
    width: 43,
    height: 38,
    position: "absolute",
  },
  rectangleParent: {
    top: 736,
    left: 5,
  },
  notifications: {
    top: 85,
    left: 124,
    fontSize: FontSize.size_xl,
    fontFamily: FontFamily.poppinsBold,
    color: Color.colorDimgray_200,
    textAlign: "left",
  },
  iphone1415Pro7: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro13;
