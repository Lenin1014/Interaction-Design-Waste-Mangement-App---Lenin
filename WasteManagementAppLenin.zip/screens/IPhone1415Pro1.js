import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, View, Text } from "react-native";
import LoginContainer from "../components/LoginContainer";
import StatusBariPhone15Pro from "../components/StatusBariPhone15Pro";
import { FontFamily, Color, Border, FontSize } from "../GlobalStyles";

const IPhone1415Pro1 = () => {
  return (
    <View style={styles.iphone1415Pro2}>
      <Image
        style={styles.iphone1415Pro2Child}
        contentFit="cover"
        source={require("../assets/vector-1.png")}
      />
      <View style={styles.homeindicator}>
        <View style={styles.homeIndicator} />
      </View>
      <LoginContainer />
      <Text style={styles.wasteManagementGovukContainer}>
        <Text style={styles.wasteManagement}>
          <Text style={styles.wasteManagement1}>Waste management</Text>
          <Text style={styles.text}>{` `}</Text>
        </Text>
        <Text style={styles.govuk}>{`Gov.uk `}</Text>
      </Text>
      <StatusBariPhone15Pro
        dynamicIsland={require("../assets/dynamic-island1.png")}
        data={require("../assets/data.png")}
        batteryMarginLeft={-199.5}
      />
      <Image
        style={styles.image1Icon}
        contentFit="cover"
        source={require("../assets/image-1.png")}
      />
      <View style={[styles.iphone1415Pro2Inner, styles.facebookParentLayout]}>
        <View style={[styles.facebookParent, styles.facebookParentLayout]}>
          <Image
            style={[styles.facebookIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/facebook.png")}
          />
          <Image
            style={styles.appleIcon}
            contentFit="cover"
            source={require("../assets/apple.png")}
          />
          <Image
            style={[styles.googleIcon, styles.iconLayout]}
            contentFit="cover"
            source={require("../assets/google.png")}
          />
        </View>
      </View>
      <Text style={styles.notAMemberContainer}>
        <Text style={styles.notAMemberContainer1}>
          <Text style={styles.notAMember}>{`Not a member yet? `}</Text>
          <Text style={styles.signUp}>Sign Up</Text>
        </Text>
      </Text>
      <Text style={[styles.forgotPassword, styles.orTypo]}>
        Forgot password
      </Text>
      <Text style={[styles.or, styles.orTypo]}>OR</Text>
      <Image
        style={[styles.iphone1415Pro2Item, styles.lineIconLayout]}
        contentFit="cover"
        source={require("../assets/line-6.png")}
      />
      <Image
        style={[styles.lineIcon, styles.lineIconLayout]}
        contentFit="cover"
        source={require("../assets/line-6.png")}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  facebookParentLayout: {
    height: 35,
    width: 135,
    position: "absolute",
  },
  iconLayout: {
    width: 34,
    height: 34,
    position: "absolute",
  },
  orTypo: {
    fontFamily: FontFamily.kokoro,
    alignItems: "flex-end",
    display: "flex",
    color: Color.labelColorLightPrimary,
    textAlign: "left",
    position: "absolute",
  },
  lineIconLayout: {
    height: 1,
    width: 165,
    position: "absolute",
  },
  iphone1415Pro2Child: {
    top: -6,
    left: -3,
    width: 405,
    height: 432,
    position: "absolute",
  },
  homeIndicator: {
    marginLeft: -67,
    bottom: 8,
    left: "50%",
    borderRadius: Border.br_81xl,
    backgroundColor: Color.labelColorLightPrimary,
    width: 134,
    height: 5,
    position: "absolute",
  },
  homeindicator: {
    top: 801,
    width: 390,
    height: 34,
    left: 0,
    position: "absolute",
  },
  wasteManagement1: {
    fontSize: FontSize.size_5xl,
  },
  text: {
    fontSize: 32,
  },
  wasteManagement: {
    fontWeight: "700",
    fontFamily: FontFamily.interBold,
    color: Color.colorForestgreen_100,
  },
  govuk: {
    fontSize: FontSize.size_xs,
    fontWeight: "600",
    fontFamily: FontFamily.interSemiBold,
    color: Color.labelColorLightPrimary,
  },
  wasteManagementGovukContainer: {
    top: 311,
    left: 63,
    width: 284,
    height: 69,
    textAlign: "left",
    position: "absolute",
  },
  image1Icon: {
    top: 74,
    left: 79,
    width: 249,
    height: 223,
    position: "absolute",
  },
  facebookIcon: {
    top: 1,
    left: 0,
  },
  appleIcon: {
    height: "96.06%",
    width: "25.11%",
    top: "0%",
    right: "37.19%",
    bottom: "3.94%",
    left: "37.7%",
    maxWidth: "100%",
    maxHeight: "100%",
    position: "absolute",
    overflow: "hidden",
  },
  googleIcon: {
    left: 101,
    top: 0,
    overflow: "hidden",
  },
  facebookParent: {
    top: 0,
    left: 0,
  },
  iphone1415Pro2Inner: {
    top: 731,
    left: 134,
  },
  notAMember: {
    color: Color.labelColorLightPrimary,
  },
  signUp: {
    color: "#32cd32",
  },
  notAMemberContainer1: {
    width: "100%",
  },
  notAMemberContainer: {
    top: 769,
    left: 59,
    fontSize: 19,
    fontFamily: FontFamily.capriolaRegular,
    width: 288,
    height: 37,
    alignItems: "flex-end",
    display: "flex",
    textAlign: "left",
    position: "absolute",
  },
  forgotPassword: {
    top: 657,
    left: 139,
    fontSize: FontSize.size_mid,
    width: 169,
    height: 47,
  },
  or: {
    top: 686,
    left: 188,
    fontSize: FontSize.size_mini,
    width: 23,
    height: 42,
  },
  iphone1415Pro2Item: {
    top: 718,
    left: 14,
  },
  lineIcon: {
    top: 717,
    left: 221,
  },
  iphone1415Pro2: {
    backgroundColor: Color.colorGray_100,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default IPhone1415Pro1;
