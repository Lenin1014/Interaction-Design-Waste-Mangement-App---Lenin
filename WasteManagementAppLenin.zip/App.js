const Stack = createNativeStackNavigator();
import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { useFonts } from "expo-font";
import IPhone1415Pro from "./screens/IPhone1415Pro";
import IPhone1415Pro1 from "./screens/IPhone1415Pro1";
import IPhone1415Pro2 from "./screens/IPhone1415Pro2";
import IPhone1415Pro3 from "./screens/IPhone1415Pro3";
import IPhone1415Pro4 from "./screens/IPhone1415Pro4";
import IPhone1415Pro5 from "./screens/IPhone1415Pro5";
import IPhone1415Pro6 from "./screens/IPhone1415Pro6";
import IPhone1415Pro7 from "./screens/IPhone1415Pro7";
import IPhone1415Pro8 from "./screens/IPhone1415Pro8";
import IPhone1415Pro9 from "./screens/IPhone1415Pro9";
import IPhone1415Pro10 from "./screens/IPhone1415Pro10";
import IPhone1415Pro11 from "./screens/IPhone1415Pro11";
import IPhone1415Pro12 from "./screens/IPhone1415Pro12";
import IPhone1415Pro13 from "./screens/IPhone1415Pro13";

import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { View, Text, Pressable, TouchableOpacity } from "react-native";

const App = () => {
  const [hideSplashScreen, setHideSplashScreen] = React.useState(true);

  const [fontsLoaded, error] = useFonts({
    "Poppins-Regular": require("./assets/fonts/Poppins-Regular.ttf"),
    "Poppins-Medium": require("./assets/fonts/Poppins-Medium.ttf"),
    "Poppins-SemiBold": require("./assets/fonts/Poppins-SemiBold.ttf"),
    "Poppins-Bold": require("./assets/fonts/Poppins-Bold.ttf"),
    "Poppins-ExtraBold": require("./assets/fonts/Poppins-ExtraBold.ttf"),
    "Inter-Regular": require("./assets/fonts/Inter-Regular.ttf"),
    "Inter-Medium": require("./assets/fonts/Inter-Medium.ttf"),
    "Inter-SemiBold": require("./assets/fonts/Inter-SemiBold.ttf"),
    "Inter-Bold": require("./assets/fonts/Inter-Bold.ttf"),
    "Inter-ExtraBold": require("./assets/fonts/Inter-ExtraBold.ttf"),
    "Capriola-Regular": require("./assets/fonts/Capriola-Regular.ttf"),
    "Nunito-Bold": require("./assets/fonts/Nunito-Bold.ttf"),
    "Montserrat-Regular": require("./assets/fonts/Montserrat-Regular.ttf"),
    "Montserrat-Medium": require("./assets/fonts/Montserrat-Medium.ttf"),
    "Montserrat-Bold": require("./assets/fonts/Montserrat-Bold.ttf"),
    "Montserrat-LightItalic": require("./assets/fonts/Montserrat-LightItalic.ttf"),
    "Roboto-Regular": require("./assets/fonts/Roboto-Regular.ttf"),
    "Roboto-Medium": require("./assets/fonts/Roboto-Medium.ttf"),
    "Roboto-Bold": require("./assets/fonts/Roboto-Bold.ttf"),
    "Rubik-Regular": require("./assets/fonts/Rubik-Regular.ttf"),
    "Rubik-Bold": require("./assets/fonts/Rubik-Bold.ttf"),
  });

  if (!fontsLoaded && !error) {
    return null;
  }

  return (
    <>
      <NavigationContainer>
        {hideSplashScreen ? (
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            <Stack.Screen
              name="IPhone1415Pro"
              component={IPhone1415Pro}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro1"
              component={IPhone1415Pro1}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro2"
              component={IPhone1415Pro2}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro3"
              component={IPhone1415Pro3}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro4"
              component={IPhone1415Pro4}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro5"
              component={IPhone1415Pro5}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro6"
              component={IPhone1415Pro6}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro7"
              component={IPhone1415Pro7}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro8"
              component={IPhone1415Pro8}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro9"
              component={IPhone1415Pro9}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro10"
              component={IPhone1415Pro10}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro11"
              component={IPhone1415Pro11}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro12"
              component={IPhone1415Pro12}
              options={{ headerShown: false }}
            />
            <Stack.Screen
              name="IPhone1415Pro13"
              component={IPhone1415Pro13}
              options={{ headerShown: false }}
            />
          </Stack.Navigator>
        ) : null}
      </NavigationContainer>
    </>
  );
};
export default App;
